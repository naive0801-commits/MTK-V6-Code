using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using MtkFlashLib.Utils;
using MtkFlashLib.Serial;

namespace MtkFlashLib
{
    /// <summary>
    /// 下载代理（DA）配置解析类，负责拆分 MTK DA 二进制、计算哈希、绕过校验以及跳转执行。
    /// </summary>
    public class DaConfig
    {
        /// <summary>
        /// 将复合的 MediaTek 下载代理（DA）二进制解析为不同阶段（DA1、DA2），并完成地址映射配置。
        /// </summary>
        public static bool ParseDaLoader(
            MtkContext context,
            byte[] daData, 
            string hwCodeInput, 
            ref string daAddress, 
            ref string daAddress2, 
            ref string daLen, 
            ref string da2Len, 
            ref string sigLen, 
            ref string sigLen2, 
            ref byte[] daLoaderFinal, 
            ref byte[] daLoaderFinal2, 
            bool patch)
        {
            // 校验输入的 DA 数据是否有效
            if (daData == null || daData.Length == 0)
            {
                context?.Log("DA 加载器源缓冲区为空或未初始化。", MtkLogLevel.Error);
                return false;
            }

            try
            {
                using (MemoryStream stream = new MemoryStream(daData))
                {
                    // 读取 DA 头部偏移 104 处的条目数量字段
                    stream.Seek(104L, SeekOrigin.Begin);
                    byte[] headerBuff = new byte[4];
                    stream.Read(headerBuff, 0, 4);

                    // 解析 DA 条目总数
                    int countElements = (int)Math.Round(Convert.ToDouble(MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(headerBuff)))) - 1.0);
                    for (int i = 0; i <= countElements; i++)
                    {
                        // 每个 DA 条目长度为 220 字节，定位到对应条目
                        stream.Seek(108 + i * 220, SeekOrigin.Begin);
                        byte[] daInfo = new byte[220];
                        stream.Read(daInfo, 0, 220);

                        // 解析条目中的各字段：CPU 代码、DA1/DA2 的偏移、大小、地址与签名长度
                        string codeCpuHeader = AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(daInfo.Take(4).ToArray()));
                        string da1Offset = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(daInfo.Skip(40).Take(4).ToArray())));
                        string da1Size = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(daInfo.Skip(44).Take(4).ToArray())));
                        string da1Address = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(daInfo.Skip(48).Take(4).ToArray())));
                        string da1SigLen = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(daInfo.Skip(56).Take(4).ToArray())));
                        string da2Offset = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(daInfo.Skip(60).Take(4).ToArray())));
                        string da2Size = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(daInfo.Skip(64).Take(4).ToArray())));
                        string da2Address = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(daInfo.Skip(68).Take(4).ToArray())));
                        string da2SigLen = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(daInfo.Skip(76).Take(4).ToArray())));

                        // 提取 CPU 代码并与目标硬件代码匹配
                        string codeCpu = codeCpuHeader.Substring(0, 4);
                        if (hwCodeInput.Contains(codeCpu))
                        {
                            // 命中目标芯片，记录各阶段地址与长度信息
                            sigLen = da1SigLen;
                            daAddress = da1Address;
                            daLen = da1Size;
                            da2Len = da2Size;
                            sigLen2 = da2SigLen;
                            daAddress2 = da2Address;

                            // 读取 DA1 阶段数据
                            stream.Seek(Convert.ToInt64(da1Offset), SeekOrigin.Begin);
                            daLoaderFinal = new byte[Convert.ToInt32(da1Size)];
                            stream.Read(daLoaderFinal, 0, daLoaderFinal.Length);

                            // 读取 DA2 阶段数据
                            stream.Seek(Convert.ToInt64(da2Offset), SeekOrigin.Begin);
                            daLoaderFinal2 = new byte[Convert.ToInt32(da2Size)];
                            stream.Read(daLoaderFinal2, 0, daLoaderFinal2.Length);

                            // 不打补丁时，仅去掉 DA2 末尾的签名段后直接返回
                            if (!patch)
                            {
                                int stripLen = Convert.ToInt32(Convert.ToDouble(daLoaderFinal2.Length) - Convert.ToDouble(sigLen2));
                                daLoaderFinal2 = daLoaderFinal2.Take(stripLen).ToArray();
                                return true;
                            }

                            // 需要打补丁：先剥离 DA2 签名段得到有效负载
                            int da2StriptSize = Convert.ToInt32(Convert.ToDouble(daLoaderFinal2.Length) - Convert.ToDouble(sigLen2));
                            byte[] da2Payload = daLoaderFinal2.Take(da2StriptSize).ToArray();

                            // 计算 DA2 哈希在 DA1 中的位置，并据此修补哈希
                            string[] hashDetails = ComputeHashPos(context, daLoaderFinal, da2Payload);
                            if (hashDetails[0] != null)
                            {
                                daLoaderFinal2 = PatchDa2(context, da2Payload);
                                daLoaderFinal = FixHashDa1(context, daLoaderFinal, daLoaderFinal2, hashDetails[0], hashDetails[1]);
                            }
                            else
                            {
                                // 未找到哈希位置时使用回退方案
                                int fallbackSize = Convert.ToInt32(Convert.ToDouble(da2Size) - Convert.ToDouble(da2SigLen));
                                daLoaderFinal2 = new byte[fallbackSize];
                            }
                            return true;
                        }
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                context?.Log("ParseDaLoader 解析异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 在 DA1 中修正 DA2 的哈希值，使其与修补后的 DA2 保持一致（支持 SHA1 / SHA256）。
        /// </summary>
        public static byte[] FixHashDa1(MtkContext context, byte[] da1, byte[] da2, string targetOffset, string hashMode)
        {
            try
            {
                string daHash = "";
                // 根据哈希模式选择对应算法计算 DA2 的哈希
                if (Convert.ToDouble(hashMode) == 1.0)
                {
                    daHash = GetSha1Hash(da2);
                }
                else if (Convert.ToDouble(hashMode) == 2.0)
                {
                    daHash = GetSha256Hash(da2);
                }

                // 将新计算的哈希写回 DA1 的目标偏移处
                using (MemoryStream stream = new MemoryStream(da1))
                {
                    stream.Seek(Convert.ToInt32(targetOffset), SeekOrigin.Begin);
                    byte[] hashBytes = AddOn.HexStringToBytes(daHash, context);
                    stream.Write(hashBytes, 0, hashBytes.Length);
                }
                return da1;
            }
            catch (Exception ex)
            {
                context?.Log("FixHashDa1 错误: " + ex.Message, MtkLogLevel.Error);
                return da1;
            }
        }

        /// <summary>
        /// 通过修补目标分支校验指令，绕过 DA2 内部的签名校验例程。
        /// </summary>
        public static byte[] PatchDa2(MtkContext context, byte[] da2)
        {
            bool patched = false;
            System.Collections.Generic.List<string> offsets = new System.Collections.Generic.List<string>();

            try
            {
                using (MemoryStream stream = new MemoryStream(da2))
                {
                    // 搜索签名校验例程特征码并进行修补
                    MtkUtils.FindOffsetBytes(da2, AddOn.HexStringToBytes("0123036000207047", context), offsets);
                    if (offsets.Count > 0)
                    {
                        stream.Seek(Convert.ToInt64(offsets[0]), SeekOrigin.Begin);
                        stream.Write(AddOn.HexStringToBytes("0023", context), 0, 2);
                        patched = true;
                    }

                    // 搜索并修补第二处校验特征码
                    offsets.Clear();
                    MtkUtils.FindOffsetBytes(da2, AddOn.HexStringToBytes("040007C0", context), offsets);
                    if (offsets.Count > 0)
                    {
                        stream.Seek(Convert.ToInt64(offsets[0]), SeekOrigin.Begin);
                        stream.Write(AddOn.HexStringToBytes("00000000", context), 0, 4);
                        patched = true;
                    }
                    else
                    {
                        // 尝试匹配其他变体特征码
                        offsets.Clear();
                        MtkUtils.FindOffsetBytes(da2, AddOn.HexStringToBytes("4FF00409CCF20709", context), offsets);
                        if (offsets.Count > 0)
                        {
                            stream.Seek(Convert.ToInt64(offsets[0]), SeekOrigin.Begin);
                            stream.Write(AddOn.HexStringToBytes("4FF000094FF00009", context), 0, 8);
                            patched = true;
                        }
                        else
                        {
                            offsets.Clear();
                            MtkUtils.FindOffsetBytes(da2, AddOn.HexStringToBytes("4FF00409324601980399CCF20709", context), offsets);
                            if (offsets.Count > 0)
                            {
                                stream.Seek(Convert.ToInt64(offsets[0]), SeekOrigin.Begin);
                                stream.Write(AddOn.HexStringToBytes("4FF000093246019803994FF00009", context), 0, 14);
                                patched = true;
                            }
                        }
                    }

                    // 搜索并修补返回值相关的校验指令
                    offsets.Clear();
                    MtkUtils.FindOffsetBytes(da2, AddOn.HexStringToBytes("37B50023044602A8", context), offsets);
                    if (offsets.Count > 0)
                    {
                        stream.Seek(Convert.ToInt64(offsets[0]), SeekOrigin.Begin);
                        stream.Write(AddOn.HexStringToBytes("37B5002003B030BD", context), 0, 8);
                        patched = true;
                    }
                    else
                    {
                        offsets.Clear();
                        MtkUtils.FindOffsetBytes(da2, AddOn.HexStringToBytes("0C23CCF20203", context), offsets);
                        if (offsets.Count > 0)
                        {
                            stream.Seek(Convert.ToInt64(offsets[0]), SeekOrigin.Begin);
                            stream.Write(AddOn.HexStringToBytes("002300230023", context), 0, 6);

                            offsets.Clear();
                            MtkUtils.FindOffsetBytes(da2, AddOn.HexStringToBytes("2A23CCF20203", context), offsets);
                            if (offsets.Count > 0)
                            {
                                stream.Seek(Convert.ToInt64(offsets[0]), SeekOrigin.Begin);
                                stream.Write(AddOn.HexStringToBytes("002300230023", context), 0, 6);
                            }
                            patched = true;
                        }
                    }
                }

                // 根据修补结果输出日志
                if (!patched)
                {
                    context?.Log("未匹配到绕过指令特征码，将以未修补的 DA 模型运行。", MtkLogLevel.Warning);
                }
                else
                {
                    context?.Log("已成功绕过 DA 校验例程。", MtkLogLevel.Success);
                }
            }
            catch (Exception ex)
            {
                context?.Log("PatchDa2 异常: " + ex.Message, MtkLogLevel.Error);
            }

            return da2;
        }

        /// <summary>
        /// 计算 DA2 的哈希在 DA1 中的位置，返回偏移量与哈希模式（1=SHA1，2=SHA256）。
        /// </summary>
        public static string[] ComputeHashPos(MtkContext context, byte[] da1, byte[] da2)
        {
            string sha1 = GetSha1Hash(da2);
            string sha256 = GetSha256Hash(da2);

            System.Collections.Generic.List<string> matchOffsets = new System.Collections.Generic.List<string>();

            // 先尝试在 DA1 中查找 SHA1 哈希
            MtkUtils.FindOffsetBytes(da1, AddOn.HexStringToBytes(sha1, context), matchOffsets);
            if (matchOffsets.Count > 0)
            {
                return new string[2] { matchOffsets[0], "1" }; // SHA1 模式
            }

            // 再尝试查找 SHA256 哈希
            matchOffsets.Clear();
            MtkUtils.FindOffsetBytes(da1, AddOn.HexStringToBytes(sha256, context), matchOffsets);
            if (matchOffsets.Count > 0)
            {
                return new string[2] { matchOffsets[0], "2" }; // SHA256 模式
            }

            return new string[2]; // 未找到匹配
        }

        /// <summary>
        /// 计算指定数据的 SHA1 哈希并返回十六进制字符串。
        /// </summary>
        public static string GetSha1Hash(byte[] content)
        {
            using (SHA1 sha1 = SHA1.Create())
            {
                byte[] hash = sha1.ComputeHash(content);
                return AddOn.BytesToHexString(hash);
            }
        }

        /// <summary>
        /// 计算指定数据的 SHA256 哈希并返回十六进制字符串。
        /// </summary>
        public static string GetSha256Hash(byte[] content)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hash = sha256.ComputeHash(content);
                return AddOn.BytesToHexString(hash);
            }
        }

        /// <summary>
        /// 指示设备跳转到 DA 执行内存块开始运行。
        /// </summary>
        public static bool JumpDa(MtkContext context, MtkPort port, string daAddressHex)
        {
            try
            {
                context?.Log("发送 DA 跳转指令地址: 0x" + daAddressHex, MtkLogLevel.Debug);
                port.Echo("D5", 1);
                port.Echo(daAddressHex, 4);

                // 校验设备响应状态
                byte[] status = port.VerifyResponse("0000", "0000") ? new byte[2] : new byte[0];
                // 回写状态响应
                port.WritePort(status);
                return true;
            }
            catch (Exception ex)
            {
                context?.Log("JumpDa 跳转失败: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }
    }
}
