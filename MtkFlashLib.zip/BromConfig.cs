using System;
using System.Collections.Generic;

namespace MtkFlashLib
{
    /// <summary>
    /// 下载代理（DA）模式常量定义。
    /// </summary>
    public static class DaModes
    {
        /// <summary>传统 Legacy DA 模式</summary>
        public const int Legacy = 3;
        /// <summary>Xflash DA 模式</summary>
        public const int Xflash = 5;
        /// <summary>XML DA 模式</summary>
        public const int Xml = 6;
    }

    /// <summary>
    /// 芯片配置信息，描述特定 MTK SOC 的各类寄存器地址与刷机参数。
    /// </summary>
    public class ChipConfig
    {
        /// <summary>芯片名称</summary>
        public string Name { get; set; }
        /// <summary>芯片描述（如商用平台名称）</summary>
        public string Description { get; set; }
        /// <summary>DA 模式（参见 DaModes）</summary>
        public int DaMode { get; set; }
        /// <summary>DA 代码标识</summary>
        public int DaCode { get; set; }
        /// <summary>看门狗寄存器地址</summary>
        public int Watchdog { get; set; }
        /// <summary>UART 寄存器地址</summary>
        public int Uart { get; set; }
        /// <summary>BROM 负载地址</summary>
        public int BromPayloadAddr { get; set; }
        /// <summary>DA 负载地址</summary>
        public int DaPayloadAddr { get; set; }
        /// <summary>Preloader 负载地址</summary>
        public int PlPayloadAddr { get; set; }
        /// <summary>GCPU 加密模块基地址</summary>
        public int GcpuBase { get; set; }
        /// <summary>SEJ 安全引擎基地址</summary>
        public int SejBase { get; set; }
        /// <summary>CQDMA 控制器基地址</summary>
        public int CqdmaBase { get; set; }
        /// <summary>AP DMA 内存地址</summary>
        public int ApDmaMem { get; set; }
        /// <summary>DXCC 加密模块基地址</summary>
        public int DxccBase { get; set; }
        /// <summary>ME-ID 地址</summary>
        public int MeidAddr { get; set; }
        /// <summary>SOC-ID 地址</summary>
        public int SocidAddr { get; set; }
        /// <summary>Provision 地址</summary>
        public int ProvAddr { get; set; }
        /// <summary>杂项锁寄存器地址</summary>
        public int MiscLock { get; set; }
        /// <summary>eFuse 地址</summary>
        public int EfuseAddr { get; set; }
        /// <summary>黑名单数量</summary>
        public int BlacklistCount { get; set; }
        /// <summary>控制缓冲区地址</summary>
        public int CtrlBuffer { get; set; }
        /// <summary>命令处理器地址</summary>
        public int CmdHandler { get; set; }
        /// <summary>黑名单地址数组</summary>
        public int[] Blacklist { get; set; } = Array.Empty<int>();
        /// <summary>发送指针数组</summary>
        public int[] SendPtr { get; set; } = Array.Empty<int>();
        /// <summary>BROM 寄存器访问地址数组</summary>
        public int[] BromRegisterAccess { get; set; } = Array.Empty<int>();
        /// <summary>加载器二进制数据</summary>
        public byte[] Loader { get; set; } = Array.Empty<byte>();
        /// <summary>Var0 - 用于漏洞利用的偏移参数</summary>
        public int? Var0 { get; set; }
        /// <summary>Var1 - 用于漏洞利用的辅助参数</summary>
        public int? Var1 { get; set; }
    }

    /// <summary>
    /// BROM 硬件配置表，按芯片硬件代码索引各 MTK SOC 的配置信息。
    /// </summary>
    public class BromConfig
    {
        /// <summary>
        /// 硬件配置字典，键为芯片硬件代码（如 "0x6765"），值为对应的芯片配置。
        /// </summary>
        public static readonly Dictionary<string, ChipConfig> HwConfig = new Dictionary<string, ChipConfig>
        {
            {
                "0x571",
                new ChipConfig
                {
                    Watchdog = 268464128,
                    DaMode = DaModes.Legacy,
                    DaCode = 1393,
                    Name = "MT0571"
                }
            },
            {
                "0x598",
                new ChipConfig
                {
                    Watchdog = 270602240,
                    Uart = 285343744,
                    BromPayloadAddr = 1051136,
                    DaPayloadAddr = 2101248,
                    GcpuBase = 270680064,
                    SejBase = 268476416,
                    CqdmaBase = 270609408,
                    ApDmaMem = 285213088,
                    DaMode = DaModes.Legacy,
                    DaCode = 1432,
                    Name = "ELBRUS/MT0598"
                }
            },
            {
                "0x992",
                new ChipConfig
                {
                    DaMode = DaModes.Xflash,
                    DaCode = 2450,
                    Name = "MT0992"
                }
            },
            {
                "0x2601",
                new ChipConfig
                {
                    Watchdog = 268464128,
                    Uart = 285233152,
                    BromPayloadAddr = 1051136,
                    DaPayloadAddr = 33587200,
                    PlPayloadAddr = -2116026368,
                    SejBase = 268476416,
                    Blacklist = new int[2] { 286531340, 0 },
                    BlacklistCount = 8,
                    SendPtr = new int[2] { 286531404, 47720 },
                    CtrlBuffer = 286534624,
                    CmdHandler = 4244911,
                    BromRegisterAccess = new int[2] { 4242760, 4243196 },
                    MeidAddr = 286534708,
                    DaCode = 9729,
                    DaMode = DaModes.Legacy,
                    Name = "MT2601"
                }
            },
            {
                "0x6261",
                new ChipConfig
                {
                    Watchdog = -1610416128,
                    Uart = -1610088448,
                    BromPayloadAddr = 1051136,
                    DaPayloadAddr = 2101248,
                    SejBase = -1609498624,
                    Blacklist = new int[2] { -536609661, 0 },
                    SendPtr = new int[2] { 1879065776, 1879070956 },
                    CtrlBuffer = 1879065000,
                    CmdHandler = 1879073270,
                    DaMode = DaModes.Legacy,
                    DaCode = 25185,
                    Name = "MT6261"
                }
            },
            {
                "0x6580",
                new ChipConfig
                {
                    Watchdog = 268464128,
                    Uart = 285233152,
                    BromPayloadAddr = 1051136,
                    DaPayloadAddr = 2101248,
                    PlPayloadAddr = -2147479552,
                    SejBase = 268476416,
                    CqdmaBase = 270576640,
                    ApDmaMem = 285213088,
                    Blacklist = new int[4] { 1058660, 0, 1077716, 0 },
                    BlacklistCount = 8,
                    SendPtr = new int[2] { 1058724, 46604 },
                    CtrlBuffer = 1060960,
                    CmdHandler = 49427,
                    BromRegisterAccess = new int[2] { 47328, 47764 },
                    EfuseAddr = 270557184,
                    MiscLock = 268441656,
                    MeidAddr = 1061044,
                    DaMode = DaModes.Legacy,
                    DaCode = 25984,
                    Name = "MT6580"
                }
            },
            {
                "0x6765",
                new ChipConfig
                {
                    Watchdog = 268464128,
                    Uart = 285220864,
                    BromPayloadAddr = 1051136,
                    DaPayloadAddr = 2101248,
                    PlPayloadAddr = 1075838976,
                    GcpuBase = 268763136,
                    SejBase = 268476416,
                    DxccBase = 270598144,
                    CqdmaBase = 270606336,
                    ApDmaMem = 285213088,
                    Blacklist = new int[4] { 1058856, 0, 1071508, 0 },
                    BlacklistCount = 10,
                    SendPtr = new int[2] { 1058924, 48576 },
                    CtrlBuffer = 1059368,
                    CmdHandler = 51949,
                    BromRegisterAccess = new int[2] { 49620, 49804 },
                    MeidAddr = 1059576,
                    SocidAddr = 1059592,
                    ProvAddr = 1070324,
                    MiscLock = 268542208,
                    EfuseAddr = 298123264,
                    DaMode = DaModes.Xflash,
                    DaCode = 26469,
                    Name = "MT6765/MT8768t",
                    Description = "Helio P35/G35"
                }
            },
            {
                "0x6768",
                new ChipConfig
                {
                    Watchdog = 268464128,
                    Uart = 285220864,
                    BromPayloadAddr = 1051136,
                    DaPayloadAddr = 2101248,
                    PlPayloadAddr = 1075838976,
                    GcpuBase = 268763136,
                    SejBase = 268476416,
                    DxccBase = 270598144,
                    CqdmaBase = 270606336,
                    ApDmaMem = 285213088,
                    Blacklist = new int[4] { 1058860, 0, 1071508, 0 },
                    BlacklistCount = 10,
                    SendPtr = new int[2] { 1058924, 49552 },
                    CtrlBuffer = 1059368,
                    CmdHandler = 53013,
                    BromRegisterAccess = new int[2] { 50584, 50768 },
                    MeidAddr = 1059576,
                    SocidAddr = 1059592,
                    ProvAddr = 1070324,
                    MiscLock = 268542208,
                    EfuseAddr = 298713088,
                    DaMode = DaModes.Xflash,
                    DaCode = 26472,
                    Name = "MT6768/MT6769",
                    Description = "Helio P65/G85"
                }
            },
            {
                "0x6877",
                new ChipConfig
                {
                    Watchdog = 268464128,
                    Uart = 285220864,
                    BromPayloadAddr = 1051136,
                    DaPayloadAddr = 2101248,
                    PlPayloadAddr = 1075838976,
                    GcpuBase = 268763136,
                    SejBase = 268476416,
                    DxccBase = 270598144,
                    CqdmaBase = 270606336,
                    ApDmaMem = 270629920,
                    Blacklist = new int[4] { 1058888, 0, 1076064, 0 },
                    BlacklistCount = 10,
                    SendPtr = new int[2] { 1058952, 59600 },
                    CtrlBuffer = 1059484,
                    CmdHandler = 63133,
                    BromRegisterAccess = new int[2] { 60632, 60816 },
                    MeidAddr = 1059736,
                    SocidAddr = 1059752,
                    ProvAddr = 1074880,
                    EfuseAddr = 301006848,
                    DaMode = DaModes.Xflash,
                    DaCode = 26743,
                    Name = "MT6877",
                    Description = "Dimensity 900"
                }
            }
        };
    }
}
