namespace MtkFlashLib
{
    /// <summary>
    /// MTK BROM/DA 通信过程中可能返回的错误码枚举。
    /// </summary>
    public enum MtkErrorCode : uint
    {
        /// <summary>无效的 DA 跳转地址</summary>
        InvalidJumpDaAddress = 7434,
        /// <summary>设备不受支持</summary>
        DeviceNotSupported = 3221356547,
        /// <summary>DAA 签名校验失败</summary>
        DaaSigVerifyFailed = 28708,
        /// <summary>DA 哈希值不匹配</summary>
        DaHashMismatch = 3221684228,
        /// <summary>镜像校验失败</summary>
        ImageVerifyFailed = 3221356551
    }
}
