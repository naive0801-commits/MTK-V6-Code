using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Numerics;

namespace MtkFlashLib.Utils
{
    /// <summary>
    /// MTK 通用工具类，提供位运算、字节查找、进制转换、字符串补齐、加解密与哈希等辅助功能。
    /// </summary>
    public class MtkUtils
    {
        /// <summary>
        /// 对以二进制字符串给出的位表示执行 AND 逻辑运算。
        /// </summary>
        public static string ApplyAnd(string input1, string input2)
        {
            // 将较短的字符串左侧补 0 至相同长度
            if (input1.Length > input2.Length)
            {
                input2 = input2.PadLeft(input1.Length, '0');
            }
            else if (input2.Length > input1.Length)
            {
                input1 = input1.PadLeft(input2.Length, '0');
            }

            // 逐位执行 AND 运算
            StringBuilder output = new StringBuilder();
            for (int k = 0; k < input1.Length; k++)
            {
                if (input1[k] == '1' && input2[k] == '1')
                {
                    output.Append('1');
                }
                else
                {
                    output.Append('0');
                }
            }
            return output.ToString();
        }

        /// <summary>
        /// 查找字节序列的对齐偏移，返回首次出现位置并收集全部匹配项。
        /// </summary>
        public static long FindOffsetBytes(byte[] inputBytes, byte[] searchPattern, System.Collections.Generic.List<string> matchOffsets = null)
        {
            if (matchOffsets != null) matchOffsets.Clear();
            if (searchPattern.Length > inputBytes.Length) return -1;

            long matchIndex = -1;
            using (BinaryReader reader = new BinaryReader(new MemoryStream(inputBytes)))
            {
                int length = (int)reader.BaseStream.Length;
                byte[] window = reader.ReadBytes(searchPattern.Length);

                // 检查起始窗口是否匹配
                bool found = true;
                for (int fnd = 0; fnd < searchPattern.Length; fnd++)
                {
                    if (window[fnd] != searchPattern[fnd])
                    {
                        found = false;
                        break;
                    }
                }
                if (found)
                {
                    matchOffsets?.Add("0");
                    return 0;
                }

                // 以滑动窗口方式逐字节向后比较
                for (int pos = searchPattern.Length; pos < length; pos++)
                {
                    Array.Copy(window, 1, window, 0, window.Length - 1);
                    window[window.Length - 1] = reader.ReadByte();

                    found = true;
                    for (int i = 0; i < searchPattern.Length; i++)
                    {
                        if (window[i] != searchPattern[i])
                        {
                            found = false;
                            break;
                        }
                    }
                    if (found)
                    {
                        long candidate = pos - (searchPattern.Length - 1);
                        if (matchIndex == -1) matchIndex = candidate;
                        matchOffsets?.Add(candidate.ToString());
                    }
                }
            }
            return matchIndex;
        }

        /// <summary>
        /// 在标准字节数组中查找字符串序列的偏移位置。
        /// </summary>
        public static long FindOffset(byte[] inputBytes, string searchString, System.Collections.Generic.List<string> matchOffsets = null)
        {
            byte[] pattern = Encoding.UTF8.GetBytes(searchString);
            return FindOffsetBytes(inputBytes, pattern, matchOffsets);
        }

        /// <summary>
        /// 将字符串右侧补齐到 16 字符（8 字节十六进制表示）。
        /// </summary>
        public static string Penggenapan8(string input)
        {
            return input.PadRight(16, '0');
        }

        /// <summary>
        /// 将字符串左侧补齐到 16 字符（8 字节十六进制表示）。
        /// </summary>
        public static string Penggenapan8Depan(string input)
        {
            return input.PadLeft(16, '0');
        }

        /// <summary>
        /// 将字符串左侧补齐到 8 字符（4 字节十六进制表示）。
        /// </summary>
        public static string Penggenapan4Depan(string input)
        {
            return input.PadLeft(8, '0');
        }

        /// <summary>
        /// 将字符串右侧补齐到 8 字符（4 字节十六进制表示）。
        /// </summary>
        public static string Penggenapan4Belakang(string input)
        {
            return input.PadRight(8, '0');
        }

        /// <summary>
        /// 将十进制数转换为十六进制字符串。
        /// </summary>
        public static string DecimalToHexadecimal(long dec)
        {
            if (dec == 0) return "00";
            if (dec < 1) return "0";
            return dec.ToString("X");
        }

        /// <summary>
        /// 将小端十六进制字节数组重新排列为正确的表示形式。
        /// </summary>
        public static string ApplyShiftKiri(string hexString)
        {
            // 保证偶数长度
            if (hexString.Length % 2 != 0)
            {
                hexString = "0" + hexString;
            }

            // 逆序拼接各字节
            StringBuilder output = new StringBuilder();
            int count = hexString.Length - 2;

            for (int i = 0; i < hexString.Length / 2; i++)
            {
                if (hexString.Substring(0, 2) != "00")
                {
                    output.Append(hexString.Substring(count, 2));
                }
                count -= 2;
            }

            // 去除前导 0 并保证偶数长度
            string result = output.ToString().TrimStart('0');
            if (result.Length % 2 != 0)
            {
                result = "0" + result;
            }

            // 在末尾补足 00，保持总字节数一致
            int margin = (hexString.Length / 2) - (result.Length / 2);
            for (int zz = 0; zz < margin; zz++)
            {
                result += "00";
            }
            return result;
        }

        /// <summary>
        /// 简单的字节序逆序拼接（不做去零或补齐处理）。
        /// </summary>
        public static string ApplyShiftKiriiiiii(string input)
        {
            StringBuilder output = new StringBuilder();
            int count = input.Length - 2;
            for (int i = 0; i < input.Length / 2; i++)
            {
                output.Append(input.Substring(count, 2));
                count -= 2;
            }
            return output.ToString();
        }

        /// <summary>
        /// 将十六进制字符串转换为十进制字符串，兼容 "none"、"0x"、"&amp;H" 前缀。
        /// </summary>
        public static string HexToDec(string hexString)
        {
            if (hexString.ToLower() == "none" || string.IsNullOrEmpty(hexString))
            {
                return "0";
            }
            // 清理前缀与空格
            string cleaned = hexString.Replace(" ", "").Replace("0x", "").Replace("&H", "");
            if (long.TryParse(cleaned, System.Globalization.NumberStyles.HexNumber, null, out long val))
            {
                return val.ToString();
            }
            return "0";
        }

        /// <summary>
        /// 将大整数转换为十六进制字符串。
        /// </summary>
        public static string LongToHex(BigInteger value)
        {
            return value.ToString("X");
        }

        /// <summary>
        /// 解密特定分区表中的敏感字段（针对 Preloader 密钥与哈希）。
        /// </summary>
        public static byte[] DecryptorSec(byte[] cipherText)
        {
            byte[] key = Encoding.UTF8.GetBytes("1A52A367CB12C458965D32CD874B36B2");
            byte[] iv = AddOn.HexStringToBytes("57325A5A125497661254976657325A5A");

            try
            {
                using (Aes algo = Aes.Create())
                {
                    // 配置 AES 参数：128 位分组、CBC 模式、无填充
                    algo.BlockSize = 128;
                    algo.FeedbackSize = 128;
                    algo.KeySize = 128;
                    algo.Mode = CipherMode.CBC;
                    algo.IV = iv;
                    algo.Key = key;
                    algo.Padding = PaddingMode.None;

                    byte[] buffOut = new byte[cipherText.Length];
                    using (ICryptoTransform decryptor = algo.CreateDecryptor())
                    using (MemoryStream streamInput = new MemoryStream(cipherText))
                    using (MemoryStream streamOutput = new MemoryStream(buffOut))
                    using (CryptoStream cryptoStream = new CryptoStream(streamOutput, decryptor, CryptoStreamMode.Write))
                    {
                        // 分块读取密文并写入解密流
                        byte[] buffer = new byte[128];
                        int bytesRead;
                        while ((bytesRead = streamInput.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            cryptoStream.Write(buffer, 0, bytesRead);
                        }
                    }
                    return buffOut;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("DecryptorSec 解密失败: " + ex.Message);
                return Array.Empty<byte>();
            }
        }

        /// <summary>
        /// 使用 HMAC-SHA512 算法计算指定明文与密钥的哈希值。
        /// </summary>
        public static byte[] ComputeHash(string clearText, string key)
        {
            UTF8Encoding encoder = new UTF8Encoding();
            using (HMACSHA512 hmac = new HMACSHA512(encoder.GetBytes(key)))
            {
                return hmac.ComputeHash(AddOn.HexStringToBytes(clearText));
            }
        }

        /// <summary>
        /// 计算 seccfg 数据的 SHA256 哈希并返回十六进制字符串。
        /// </summary>
        public static string EncSeccfg(string data)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hash = sha256.ComputeHash(AddOn.HexStringToBytes(data));
                return AddOn.BytesToHexString(hash);
            }
        }

        /// <summary>
        /// 尝试使用指定密码以 AES-ECB 模式解密字节数据。
        /// </summary>
        public static bool TryDecryptBytes(ref byte[] data, string password, MtkContext context = null)
        {
            try
            {
                using (Aes rm = Aes.Create())
                {
                    rm.Mode = CipherMode.ECB;
                    rm.Padding = PaddingMode.None;
                    rm.Key = Encoding.UTF8.GetBytes(password);

                    using (ICryptoTransform decryptor = rm.CreateDecryptor())
                    {
                        data = decryptor.TransformFinalBlock(data, 0, data.Length);
                    }
                }
                context?.Log("解密成功，解密后数据字节长度: " + data.Length, MtkLogLevel.Debug);
                return true;
            }
            catch (Exception ex)
            {
                context?.Log("解密失败: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 使用 HMAC-SHA256 算法计算固定数据的哈希值（密钥与数据为内置常量）。
        /// </summary>
        public static string GetSha256(string content)
        {
            byte[] key = AddOn.HexStringToBytes("62DDE5B241D5EB467B577C04737FBCD4");
            using (HMACSHA256 hmac = new HMACSHA256(key))
            {
                byte[] bytes = hmac.ComputeHash(AddOn.HexStringToBytes("44ED75BBF9E6D0701022E954F0549D552D7C67AF9F8926F90B2638B4EBAE31D4"));
                return AddOn.BytesToHexString(bytes);
            }
        }

        /// <summary>
        /// 将字节大小格式化为人类可读的文件大小字符串（如 "1.50 MB"）。
        /// </summary>
        public static string GetFileSize(long size)
        {
            // 依次按 TB / GB / MB / KB 单位换算
            if (size >= 1099511627776L)
            {
                double tb = (double)size / 1099511627776.0;
                return tb.ToString("F2") + " TB";
            }
            else if (size >= 1073741824)
            {
                double gb = (double)size / 1073741824.0;
                return gb.ToString("F2") + " GB";
            }
            else if (size >= 1048576)
            {
                double mb = (double)size / 1048576.0;
                return mb.ToString("F2") + " MB";
            }
            else if (size >= 1024)
            {
                double kb = (double)size / 1024.0;
                return kb.ToString("F2") + " KB";
            }
            else
            {
                return size.ToString() + " bytes";
            }
        }
    }
}
