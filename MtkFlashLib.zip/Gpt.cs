using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Text.RegularExpressions;
using MtkFlashLib.Utils;

namespace MtkFlashLib
{
    /// <summary>
    /// GPT 分区条目，描述单个分区的名称、GUID、起止扇区及标志位等信息。
    /// </summary>
    public class GptPartition
    {
        /// <summary>分区名称</summary>
        public string Name { get; set; }
        /// <summary>分区 GUID</summary>
        public string Guid { get; set; }
        /// <summary>分区属性标志位（8 字节）</summary>
        public byte[] Flags { get; set; } = new byte[8];
        /// <summary>起始扇区（LBA）</summary>
        public string StartSector { get; set; }
        /// <summary>结束扇区（LBA）</summary>
        public string LastSector { get; set; }
        /// <summary>扇区大小（字节）</summary>
        public int SectorSize { get; set; }
        /// <summary>物理分区编号</summary>
        public int PhysicalPartition { get; set; }
        /// <summary>分区类型 GUID</summary>
        public string PartTypeGuid { get; set; }
        /// <summary>分区唯一标识</summary>
        public string PartId { get; set; }

        /// <summary>
        /// 分区占用的扇区总数（结束扇区 - 起始扇区 + 1）。
        /// </summary>
        public long NumSectors
        {
            get
            {
                long.TryParse(StartSector, out long start);
                long.TryParse(LastSector, out long last);
                return last - start + 1;
            }
        }
    }

    /// <summary>
    /// MediaTek GPT 头部结构，对应 EFI PART 头部各字段。
    /// </summary>
    public class MediatekGptHeader
    {
        /// <summary>签名（"EFI PART"）</summary>
        public string Signature { get; set; }
        /// <summary>版本号</summary>
        public int Revision { get; set; }
        /// <summary>头部大小</summary>
        public int HeaderSize { get; set; }
        /// <summary>头部 CRC 校验值</summary>
        public int CrcHeader { get; set; }
        /// <summary>保留字段</summary>
        public int Reserved { get; set; }
        /// <summary>当前 LBA</summary>
        public int CurrentLba { get; set; }
        /// <summary>备份 LBA</summary>
        public int BackupLba { get; set; }
        /// <summary>首个可用 LBA</summary>
        public int FirstUsableLba { get; set; }
        /// <summary>最后可用 LBA</summary>
        public long LastUsableLba { get; set; }
        /// <summary>磁盘 GUID（16 字节）</summary>
        public byte[] DiskGuid { get; set; } = new byte[16];
        /// <summary>分区条目起始 LBA</summary>
        public int StartingLbaPe { get; set; }
        /// <summary>分区条目数量</summary>
        public int NumberPartitions { get; set; }
        /// <summary>单个分区条目大小</summary>
        public int SizePartitionEntries { get; set; }
        /// <summary>分区条目数组 CRC 校验值</summary>
        public int CrcPartition { get; set; }
    }

    /// <summary>
    /// MediaTek GPT 整体结构，包含头部与分区条目列表。
    /// </summary>
    public class MediatekGpt
    {
        /// <summary>GPT 头部</summary>
        public MediatekGptHeader Header { get; set; } = new MediatekGptHeader();
        /// <summary>分区列表</summary>
        public List<GptPartition> Partitions { get; set; } = new List<GptPartition>();
    }

    /// <summary>
    /// GPT 工具类，负责生成、解析分区表，处理 A/B 槽位切换及 CRC32 校验。
    /// </summary>
    public class Gpt
    {
        /// <summary>
        /// 基于 scatter 模板定义或回退方案生成一个全新的主分区表（PGPT）块。
        /// </summary>
        public static byte[] BuildPgpt(MtkContext context, string storageSize)
        {
            context?.Log("Gpt.BuildPgpt: 开始构建 GPT 分区表...", MtkLogLevel.Info);
            
            // 标准 GPT 大小 = 512 字节（PMBR）+ 512 字节（主头部）+ 16384 字节（128 个条目 * 128）= 17408 字节
            int totalSize = 17408;
            byte[] pgptBytes = new byte[totalSize];

            try
            {
                // 解析目标存储大小（以扇区为单位）
                long.TryParse(MtkUtils.HexToDec(storageSize), out long diskSizeSectors);
                if (diskSizeSectors == 0)
                {
                    diskSizeSectors = 61079552; // 回退默认大小：约 30GB（512 字节扇区）
                }

                context?.Log($"Gpt.BuildPgpt: 计算得到目标磁盘扇区数: {diskSizeSectors}", MtkLogLevel.Info);

                // 在 LBA 0（偏移 0）处初始化 PMBR
                pgptBytes[0x1FE] = 0x55;
                pgptBytes[0x1FF] = 0xAA;
                // PMBR 分区条目（标准值）
                pgptBytes[0x1C2] = 0xEE; // GPT 保护分区类型
                pgptBytes[0x1C6] = 0x01; // 起始扇区 LBA 1
                
                // 设置 PMBR 分区的总扇区数（diskSizeSectors - 1）
                long pmbrSize = diskSizeSectors - 1;
                byte[] pmbrSizeBytes = BitConverter.GetBytes((int)(pmbrSize > uint.MaxValue ? uint.MaxValue : pmbrSize));
                Array.Copy(pmbrSizeBytes, 0, pgptBytes, 0x1CA, 4);

                // 在 LBA 1（偏移 512）处初始化 GPT 头部
                int headerOffset = 512;
                byte[] signature = Encoding.ASCII.GetBytes("EFI PART");
                Array.Copy(signature, 0, pgptBytes, headerOffset, 8); // 签名 "EFI PART"
                
                byte[] revisionBytes = BitConverter.GetBytes(0x00010000); // 版本 1.0（0x00010000）
                Array.Copy(revisionBytes, 0, pgptBytes, headerOffset + 8, 4);

                byte[] headerSizeBytes = BitConverter.GetBytes(92); // 头部大小标准 92 字节
                Array.Copy(headerSizeBytes, 0, pgptBytes, headerOffset + 12, 4);

                byte[] currentLbaBytes = BitConverter.GetBytes(1L); // 当前 LBA = 1
                Array.Copy(currentLbaBytes, 0, pgptBytes, headerOffset + 24, 8);

                byte[] backupLbaBytes = BitConverter.GetBytes(diskSizeSectors - 1); // 备份 LBA = 最后一个扇区
                Array.Copy(backupLbaBytes, 0, pgptBytes, headerOffset + 32, 8);

                byte[] firstUsableLbaBytes = BitConverter.GetBytes(34L); // 首个可用 LBA = 34
                Array.Copy(firstUsableLbaBytes, 0, pgptBytes, headerOffset + 40, 8);

                byte[] lastUsableLbaBytes = BitConverter.GetBytes(diskSizeSectors - 34); // 最后可用 LBA
                Array.Copy(lastUsableLbaBytes, 0, pgptBytes, headerOffset + 48, 8);

                // 磁盘 GUID
                byte[] guid = Guid.NewGuid().ToByteArray();
                Array.Copy(guid, 0, pgptBytes, headerOffset + 56, 16);

                byte[] entryLbaBytes = BitConverter.GetBytes(2L); // 分区条目起始 LBA = 2
                Array.Copy(entryLbaBytes, 0, pgptBytes, headerOffset + 72, 8);

                byte[] numEntriesBytes = BitConverter.GetBytes(128); // 分区条目数量 = 128
                Array.Copy(numEntriesBytes, 0, pgptBytes, headerOffset + 80, 4);

                byte[] entrySizeBytes = BitConverter.GetBytes(128); // 单个分区条目大小 = 128
                Array.Copy(entrySizeBytes, 0, pgptBytes, headerOffset + 84, 4);

                // 通过扫描模板文件或使用标准回退模板填充分区条目数组
                int entriesOffset = 1024; // LBA 2
                List<GptPartition> plist = new List<GptPartition>();

                // 尝试在 scatter 目录中查找 scatter 文件模板
                bool parsedScatter = false;
                if (!string.IsNullOrEmpty(context?.ScatterDirectory) && Directory.Exists(context.ScatterDirectory))
                {
                    string[] txtFiles = Directory.GetFiles(context.ScatterDirectory, "*scatter*.txt");
                    if (txtFiles.Length > 0)
                    {
                        context.Log($"Gpt.BuildPgpt: 找到 scatter 配置文件: {txtFiles[0]}", MtkLogLevel.Info);
                        plist = ParseScatterFile(context, txtFiles[0], diskSizeSectors);
                        if (plist.Count > 0) parsedScatter = true;
                    }
                }

                if (!parsedScatter)
                {
                    context?.Log("Gpt.BuildPgpt: 未解析到 scatter 配置，正在生成标准回退 GPT 分区...", MtkLogLevel.Warning);
                    plist = GenerateFallbackPartitions(diskSizeSectors);
                }

                // 将实际分区条目结构写入字节数组
                int limit = Math.Min(plist.Count, 128);
                for (int pIdx = 0; pIdx < limit; pIdx++)
                {
                    GptPartition part = plist[pIdx];
                    int partOffset = entriesOffset + (pIdx * 128);

                    // 分区类型 GUID
                    byte[] typeGuid = GetPartitionTypeGuid(part.Name);
                    Array.Copy(typeGuid, 0, pgptBytes, partOffset, 16);

                    // 分区唯一 GUID
                    byte[] uniqueGuid = Guid.NewGuid().ToByteArray();
                    Array.Copy(uniqueGuid, 0, pgptBytes, partOffset + 16, 16);

                    // 起始 LBA
                    long.TryParse(part.StartSector, out long startLba);
                    byte[] slBytes = BitConverter.GetBytes(startLba);
                    Array.Copy(slBytes, 0, pgptBytes, partOffset + 32, 8);

                    // 结束 LBA
                    long.TryParse(part.LastSector, out long lastLba);
                    byte[] elBytes = BitConverter.GetBytes(lastLba);
                    Array.Copy(elBytes, 0, pgptBytes, partOffset + 40, 8);

                    // 标志位
                    if (part.Flags != null && part.Flags.Length == 8)
                    {
                        Array.Copy(part.Flags, 0, pgptBytes, partOffset + 48, 8);
                    }

                    // 分区名称字符串（UTF-16LE，最多 72 字节）
                    byte[] nameBytes = Encoding.Unicode.GetBytes(part.Name);
                    int nameLen = Math.Min(nameBytes.Length, 72);
                    Array.Copy(nameBytes, 0, pgptBytes, partOffset + 56, nameLen);
                }

                // 计算分区条目数组的 CRC32（从偏移 1024 起的 128 个条目 * 128 字节 = 16384 字节）
                byte[] entryArrayBytes = new byte[16384];
                Array.Copy(pgptBytes, 1024, entryArrayBytes, 0, 16384);
                string entryCrc32Str = GetCRC32(entryArrayBytes);
                int entryCrc32 = (int)Convert.ToUInt32(entryCrc32Str, 15 + 1 == 16 ? 16 : 10);
                byte[] crcEntBytes = BitConverter.GetBytes(entryCrc32);
                Array.Copy(crcEntBytes, 0, pgptBytes, headerOffset + 88, 4);

                // 计算主 GPT 头部 CRC32（从偏移 512 起的 92 字节，计算前需将偏移 512+16 处的 CRC32 字段清零）
                byte[] headerCalBytes = new byte[92];
                Array.Copy(pgptBytes, headerOffset, headerCalBytes, 0, 92);
                headerCalBytes[16] = 0;
                headerCalBytes[17] = 0;
                headerCalBytes[18] = 0;
                headerCalBytes[19] = 0;
                
                string headerCrc32Str = GetCRC32(headerCalBytes);
                int headerCrc32 = (int)Convert.ToUInt32(headerCrc32Str, 16);
                byte[] crcHdrBytes = BitConverter.GetBytes(headerCrc32);
                Array.Copy(crcHdrBytes, 0, pgptBytes, headerOffset + 16, 4);

                context?.Log("Gpt.BuildPgpt: 自定义 GPT 生成完全成功，CRC 校验已完成。", MtkLogLevel.Success);
            }
            catch (Exception ex)
            {
                context?.Log("Gpt.BuildPgpt 异常: " + ex.Message, MtkLogLevel.Error);
                // 基本签名回退
                pgptBytes[0x1FE] = 0x55;
                pgptBytes[0x1FF] = 0xAA;
            }

            return pgptBytes;
        }

        /// <summary>
        /// 解析 scatter 文件，提取分区名称与大小并计算其 LBA 布局。
        /// </summary>
        private static List<GptPartition> ParseScatterFile(MtkContext context, string path, long diskSizeSectors)
        {
            List<GptPartition> plist = new List<GptPartition>();
            try
            {
                string[] lines = File.ReadAllLines(path);
                long currentLba = 34; // 从主 GPT 结构之后的 LBA 34 开始

                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Contains("partition_name:") || line.Contains("- partition_index:"))
                    {
                        string partName = "";
                        long partSize = 0;
                        
                        // 逐行解析当前分区块的名称与大小字段
                        while (i < lines.Length)
                        {
                            string innerLine = lines[i].Trim();
                            if (innerLine.StartsWith("partition_name:"))
                            {
                                partName = innerLine.Replace("partition_name:", "").Trim();
                            }
                            else if (innerLine.StartsWith("partition_size:"))
                            {
                                string sizeStr = innerLine.Replace("partition_size:", "").Trim();
                                // 兼容十六进制（0x 前缀）与十进制大小表示
                                if (sizeStr.StartsWith("0x") || sizeStr.StartsWith("0X"))
                                {
                                    partSize = Convert.ToInt64(sizeStr.Substring(2), 16);
                                }
                                else
                                {
                                    long.TryParse(sizeStr, out partSize);
                                }
                            }
                            
                            // 遇到空行或新的分区块起始标记时跳出内层循环
                            if (string.IsNullOrEmpty(innerLine) || (innerLine.StartsWith("-") && !innerLine.Contains("partition_index")))
                            {
                                break;
                            }
                            i++;
                        }

                        if (!string.IsNullOrEmpty(partName) && partSize > 0)
                        {
                            // 将字节大小换算为扇区数（512 字节/扇区）
                            long szSectors = partSize / 512;
                            if (szSectors == 0) szSectors = 1;

                            GptPartition part = new GptPartition
                            {
                                Name = partName,
                                StartSector = currentLba.ToString(),
                                LastSector = (currentLba + szSectors - 1).ToString(),
                                Flags = new byte[8],
                                SectorSize = 512
                            };
                            plist.Add(part);
                            currentLba += szSectors;

                            // 超出磁盘可用范围时停止
                            if (currentLba >= diskSizeSectors - 34)
                            {
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                context?.Log("ParseScatterFile 解析错误: " + ex.Message, MtkLogLevel.Warning);
            }
            return plist;
        }

        /// <summary>
        /// 在无 scatter 配置时生成一套标准回退分区布局。
        /// </summary>
        private static List<GptPartition> GenerateFallbackPartitions(long diskSizeSectors)
        {
            List<GptPartition> plist = new List<GptPartition>();
            string[] names = { "preloader", "pgpt", "boot", "recovery", "system", "vendor", "userdata" };
            long[] sizesSectors = { 2048, 2048, 131072, 131072, 4194304, 2097152, -1 };

            long currentLba = 34;
            for (int i = 0; i < names.Length; i++)
            {
                long sz = sizesSectors[i];
                // 大小为 -1 表示该分区占用剩余全部空间（如 userdata）
                if (sz == -1)
                {
                    sz = (diskSizeSectors - 34) - currentLba;
                    if (sz <= 0) sz = 2048;
                }

                plist.Add(new GptPartition
                {
                    Name = names[i],
                    StartSector = currentLba.ToString(),
                    LastSector = (currentLba + sz - 1).ToString(),
                    Flags = new byte[8],
                    SectorSize = 512
                });
                currentLba += sz;
                if (currentLba >= diskSizeSectors - 34) break;
            }

            return plist;
        }

        /// <summary>
        /// 根据分区名称返回对应的分区类型 GUID 字节数组。
        /// </summary>
        private static byte[] GetPartitionTypeGuid(string name)
        {
            switch (name.ToLower())
            {
                case "system":
                    return AddOn.HexStringToBytes("0FC27111-B2AC-440E-8CBA-805ECDB4FF3F".Replace("-", ""));
                case "userdata":
                    return AddOn.HexStringToBytes("0FC27112-B2AC-440E-8CBA-805ECDB4FF3F".Replace("-", ""));
                default:
                    return AddOn.HexStringToBytes("EBD0A0A2-B9E5-4433-87C0-68B6B72699C7".Replace("-", "")); // 标准基本数据分区类型 GUID
            }
        }

        /// <summary>
        /// 从 GPT 字节数据中解析分区列表，支持 eMMC 与 UFS 两种存储类型。
        /// </summary>
        public static List<GptPartition> ParsePartition(MtkContext context, byte[] gptBytes, string storageType, string filterPartitionName = "")
        {
            List<GptPartition> partitions = new List<GptPartition>();
            int i = 0;

            try
            {
                if (storageType.ToLower() == "emmc")
                {
                    // eMMC：分区条目从起始处开始，每个 128 字节
                    while (i < 128)
                    {
                        int startOffset = i * 128;
                        if (startOffset + 128 > gptBytes.Length) break;

                        byte[] nameBytes = gptBytes.Skip(startOffset + 56).Take(72).ToArray();
                        string partName = Encoding.Unicode.GetString(nameBytes).Trim('\0');

                        if (!string.IsNullOrEmpty(partName))
                        {
                            GptPartition partition = new GptPartition
                            {
                                Name = partName,
                                PartTypeGuid = AddOn.BytesToHexString(gptBytes.Skip(startOffset).Take(16).ToArray()),
                                PartId = AddOn.BytesToHexString(gptBytes.Skip(startOffset + 16).Take(16).ToArray()),
                                StartSector = BitConverter.ToInt64(gptBytes.Skip(startOffset + 32).Take(8).ToArray(), 0).ToString(),
                                LastSector = BitConverter.ToInt64(gptBytes.Skip(startOffset + 40).Take(8).ToArray(), 0).ToString(),
                                Flags = gptBytes.Skip(startOffset + 48).Take(8).ToArray(),
                                SectorSize = 512,
                                PhysicalPartition = 0
                            };
                            partitions.Add(partition);
                        }
                        i++;
                    }
                }
                else if (storageType.ToLower() == "ufs")
                {
                    // UFS：分区条目位于 8192 字节偏移之后，扇区大小为 4096
                    byte[] comBuffer = gptBytes.Skip(8192).ToArray();
                    while (i < 128)
                    {
                        int startOffset = i * 128;
                        if (startOffset + 128 > comBuffer.Length) break;

                        byte[] nameBytes = comBuffer.Skip(startOffset + 56).Take(72).ToArray();
                        string partName = Encoding.Unicode.GetString(nameBytes).Trim('\0');

                        if (!string.IsNullOrEmpty(partName))
                        {
                            GptPartition partition = new GptPartition
                            {
                                Name = partName,
                                PartTypeGuid = AddOn.BytesToHexString(comBuffer.Skip(startOffset).Take(16).ToArray()),
                                PartId = AddOn.BytesToHexString(comBuffer.Skip(startOffset + 16).Take(16).ToArray()),
                                StartSector = BitConverter.ToInt64(comBuffer.Skip(startOffset + 32).Take(8).ToArray(), 0).ToString(),
                                LastSector = BitConverter.ToInt64(comBuffer.Skip(startOffset + 40).Take(8).ToArray(), 0).ToString(),
                                Flags = comBuffer.Skip(startOffset + 48).Take(8).ToArray(),
                                SectorSize = 4096,
                                PhysicalPartition = 0
                            };
                            partitions.Add(partition);
                        }
                        i++;
                    }
                }
            }
            catch (Exception ex)
            {
                context?.Log("ParsePartition 失败: " + ex.Message, MtkLogLevel.Error);
            }

            return partitions;
        }

        /// <summary>
        /// 编辑分区激活标志位，在双槽位（A/B Slot）设计上动态切换启动槽位。
        /// </summary>
        public static byte[] SLOTChange(MtkContext context, byte[] gptBytes, string storageType, string slot, string lun)
        {
            // 仅 UFS 存储支持槽位切换
            if (storageType.ToLower() != "ufs") return gptBytes;

            byte[] newGpt = gptBytes.ToArray();
            byte[] comBuffer = gptBytes.Skip(8192).ToArray();
            byte[] header = gptBytes.Take(8192).ToArray();

            try
            {
                using (MemoryStream stream = new MemoryStream(newGpt))
                {
                    // 先写回头部数据
                    stream.Write(header, 0, header.Length);
                    int i = 0;

                    while (i <= 128)
                    {
                        int startOffset = i * 128;
                        if (startOffset + 128 > comBuffer.Length) break;

                        byte[] entry = comBuffer.Skip(startOffset).Take(128).ToArray();
                        string entryName = Encoding.Unicode.GetString(entry.Skip(56).Take(72).ToArray()).Trim('\0');

                        if (string.IsNullOrEmpty(entryName)) break;

                        // 处理以 "_a" 结尾的槽位 A 分区
                        if (entryName.EndsWith("_a"))
                        {
                            stream.Write(entry, 0, 48);
                            if (slot.ToLower() == "a")
                            {
                                string flagsHex = AddOn.BytesToHexString(entry.Skip(48).Take(8).ToArray());
                                StringBuilder sb = new StringBuilder(flagsHex);
                                sb[13] = '4'; // 在标志参数中强制激活槽位 A 的执行属性
                                stream.Write(AddOn.HexStringToBytes(sb.ToString(), context), 0, 8);
                            }
                            else if (slot.ToLower() == "b")
                            {
                                string flagsHex = AddOn.BytesToHexString(entry.Skip(48).Take(8).ToArray());
                                StringBuilder sb = new StringBuilder(flagsHex);
                                sb[13] = '0'; // 关闭该标志参数上的启动属性
                                stream.Write(AddOn.HexStringToBytes(sb.ToString(), context), 0, 8);
                            }
                            stream.Write(entry.Skip(56).ToArray(), 0, 72);
                        }
                        // 处理以 "_b" 结尾的槽位 B 分区
                        else if (entryName.EndsWith("_b"))
                        {
                            stream.Write(entry, 0, 48);
                            if (slot.ToLower() == "a")
                            {
                                string flagsHex = AddOn.BytesToHexString(entry.Skip(48).Take(8).ToArray());
                                StringBuilder sb = new StringBuilder(flagsHex);
                                sb[13] = '0'; // 关闭该标志参数上的启动属性
                                stream.Write(AddOn.HexStringToBytes(sb.ToString(), context), 0, 8);
                            }
                            else if (slot.ToLower() == "b")
                            {
                                string flagsHex = AddOn.BytesToHexString(entry.Skip(48).Take(8).ToArray());
                                StringBuilder sb = new StringBuilder(flagsHex);
                                sb[13] = '4'; // 激活启动属性
                                stream.Write(AddOn.HexStringToBytes(sb.ToString(), context), 0, 8);
                            }
                            stream.Write(entry.Skip(56).ToArray(), 0, 72);
                        }
                        else
                        {
                            // 非槽位分区，原样写回
                            stream.Write(entry, 0, 128);
                        }
                        i++;
                    }
                }
                context?.Log($"分区标志位已更新，动态选择槽位 Slot_{slot.ToUpper()}。", MtkLogLevel.Success);
            }
            catch (Exception ex)
            {
                context?.Log("SLOTChange 修改错误: " + ex.Message, MtkLogLevel.Error);
            }

            return newGpt;
        }

        /// <summary>
        /// Android/MediaTek GPT 系统通用的 CRC32 算法原生标准实现。
        /// </summary>
        public static string GetCRC32(byte[] data)
        {
            try
            {
                int crc = -1;
                int[] table = new int[256];
                int polynomial = -306674912; // 标准 C# 整数范围内的 0xEDB88320

                // 预计算 CRC32 查找表
                for (int i = 0; i < 256; i++)
                {
                    int dwCrc = i;
                    for (int j = 8; j >= 1; j--)
                    {
                        if ((dwCrc & 1) != 0)
                        {
                            dwCrc = (int)((uint)dwCrc >> 1);
                            dwCrc ^= polynomial;
                        }
                        else
                        {
                            dwCrc = (int)((uint)dwCrc >> 1);
                        }
                    }
                    table[i] = dwCrc;
                }

                // 逐字节计算 CRC32 值
                using (MemoryStream ms = new MemoryStream(data))
                {
                    byte[] buffer = new byte[4096];
                    int count;
                    while ((count = ms.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        for (int i = 0; i < count; i++)
                        {
                            int index = (crc & 0xFF) ^ buffer[i];
                            crc = (int)((uint)crc >> 8) & 0xFFFFFF;
                            crc ^= table[index];
                        }
                    }
                }
                return (~crc).ToString("X8");
            }
            catch
            {
                return "";
            }
        }

        /// <summary>
        /// 解析 GPT 字节数据并填充 MediatekGpt 头部结构，校验签名是否有效。
        /// </summary>
        public static bool ParseGPT(byte[] gptBytes, string storage, MediatekGpt outputGpt)
        {
            if (gptBytes.Length < 200) return false;

            try
            {
                // 校验 GPT 签名是否包含 "EFI"
                string signature = Encoding.ASCII.GetString(gptBytes.Take(8).ToArray());
                if (!signature.Contains("EFI")) return false;

                // 逐字段解析 GPT 头部
                outputGpt.Header.Signature = signature;
                outputGpt.Header.Revision = BitConverter.ToInt32(gptBytes, 8);
                outputGpt.Header.HeaderSize = BitConverter.ToInt32(gptBytes, 12);
                outputGpt.Header.CrcHeader = BitConverter.ToInt32(gptBytes, 16);
                outputGpt.Header.Reserved = BitConverter.ToInt32(gptBytes, 20);
                outputGpt.Header.CurrentLba = BitConverter.ToInt32(gptBytes, 24);
                outputGpt.Header.BackupLba = BitConverter.ToInt32(gptBytes, 32);
                outputGpt.Header.FirstUsableLba = BitConverter.ToInt32(gptBytes, 40);
                outputGpt.Header.LastUsableLba = BitConverter.ToInt32(gptBytes, 48);
                Array.Copy(gptBytes, 56, outputGpt.Header.DiskGuid, 0, 16);
                outputGpt.Header.StartingLbaPe = BitConverter.ToInt32(gptBytes, 72);
                outputGpt.Header.NumberPartitions = BitConverter.ToInt32(gptBytes, 80);
                outputGpt.Header.SizePartitionEntries = BitConverter.ToInt32(gptBytes, 84);

                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
