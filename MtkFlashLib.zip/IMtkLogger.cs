namespace MtkFlashLib
{
    /// <summary>
    /// 日志级别枚举，用于区分不同类型的日志输出。
    /// </summary>
    public enum MtkLogLevel
    {
        /// <summary>普通信息</summary>
        Info,
        /// <summary>操作成功</summary>
        Success,
        /// <summary>警告信息</summary>
        Warning,
        /// <summary>错误信息</summary>
        Error,
        /// <summary>调试信息</summary>
        Debug
    }

    /// <summary>
    /// MTK 日志接口，宿主程序通过实现该接口接收库内部的日志与进度回调。
    /// </summary>
    public interface IMtkLogger
    {
        /// <summary>
        /// 向宿主控制台或日志接口写入一条标准日志记录。
        /// </summary>
        /// <param name="message">日志内容</param>
        /// <param name="level">日志级别</param>
        void Log(string message, MtkLogLevel level);

        /// <summary>
        /// 更新长时间运行任务的进度状态（例如刷写或转储分区）。
        /// </summary>
        /// <param name="task">任务名称</param>
        /// <param name="current">当前已处理量</param>
        /// <param name="total">总量</param>
        /// <param name="speed">速度信息（可选）</param>
        void UpdateProgress(string task, long current, long total, string speed = "");
    }
}
