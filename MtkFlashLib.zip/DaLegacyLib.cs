using System;
using System.IO;
using System.Threading;
using MtkFlashLib.Serial;
using MtkFlashLib.Utils;

namespace MtkFlashLib
{
    /// <summary>
    /// 传统（Legacy）下载代理库，负责向 MTK BROM 下发配置补丁块及传输 DA 二进制负载。
    /// </summary>
    public class DaLegacyLib
    {
        /// <summary>默认 DA 负载地址</summary>
        public static readonly string DefaultDaPayloadAddr = "33587200";
        /// <summary>默认 BROM 负载地址</summary>
        public static readonly int DefaultBromPayloadAddr = 1051136;

        /// <summary>
        /// 通过已打开的通道下发配置补丁块，用于在 DA 中配置特定的硬件地址。
        /// </summary>
        public static bool PatchDa(MtkContext context, MtkPort port, string param1, string param2)
        {
            try
            {
                // 发送魔术头与命令块，请求进入配置写入流程
                port.WritePort(AddOn.HexStringToBytes("EFEEEEFE01000000 08 00 00 00"));
                port.WritePort(AddOn.HexStringToBytes("08000100"));
                Thread.Sleep(100);

                // 读取并校验设备状态响应
                string status = AddOn.BytesToHexString(port.VerifyResponse("0000", "0000") ? new byte[2] : new byte[0]);

                // 计算并下发第一个参数块的长度及数据
                string len1 = MtkUtils.DecimalToHexadecimal((long)Math.Round((double)param1.Replace(" ", "").Length / 2.0));
                string formattedLen1 = MtkUtils.Penggenapan4Belakang(len1);
                port.WritePort(AddOn.HexStringToBytes("EFEEEEFE01000000" + formattedLen1));
                port.WritePort(AddOn.HexStringToBytes(param1));

                // 计算并下发第二个参数块的长度及数据
                string len2 = MtkUtils.DecimalToHexadecimal((long)Math.Round((double)param2.Replace(" ", "").Length / 2.0));
                string formattedLen2 = MtkUtils.Penggenapan4Belakang(len2);
                port.WritePort(AddOn.HexStringToBytes("EFEEEEFE01000000" + formattedLen2));
                port.WritePort(AddOn.HexStringToBytes(param2));

                Thread.Sleep(100);
                return true;
            }
            catch (Exception ex)
            {
                context?.Log("PatchDa 硬件配置失败: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 向 MTK BROM 传输原始二进制负载（如 DA1 镜像），并实时上报传输进度百分比。
        /// </summary>
        public static bool SendDa(MtkContext context, MtkPort port, string daAddressHex, string daLength, string sigLen, byte[] daBytes)
        {
            try
            {
                context?.Log($"正在向目标地址 0x{daAddressHex} 传输主 DA 负载...", MtkLogLevel.Info);
                // 下发发送 DA 命令及地址、长度、签名长度参数
                port.Echo("d7", 1);
                port.Echo(daAddressHex, 4);
                port.Echo(daLength, 4);
                port.Echo(sigLen, 4);

                // 读取确认响应
                byte[] ackResponse = port.VerifyResponse("0000", "0000") ? new byte[2] : new byte[0];

                // 分块传输负载数据
                int remainingBytes = daBytes.Length;
                int writtenBytes = 0;
                int chunkSize = 8192;
                byte[] chunkBuffer = new byte[chunkSize];

                using (MemoryStream stream = new MemoryStream(daBytes))
                {
                    while (remainingBytes > 0)
                    {
                        // 处理最后一块不足 chunkSize 的情况
                        if (remainingBytes < chunkSize)
                        {
                            chunkSize = daBytes.Length - writtenBytes;
                        }

                        chunkBuffer = new byte[chunkSize];
                        int bytesRead = stream.Read(chunkBuffer, 0, chunkSize);
                        remainingBytes -= bytesRead;
                        writtenBytes += bytesRead;

                        port.WritePort(chunkBuffer);
                        // 上报传输进度
                        context?.UpdateProgress("SENDING_DA_STAGE_1", writtenBytes, daBytes.Length, "正在传输 BROM 负载数据块...");
                    }
                }

                context?.Log("DA1 负载发送成功，等待 BROM 状态同步...", MtkLogLevel.Debug);
                return true;
            }
            catch (Exception ex)
            {
                context?.Log("SendDa 传输失败: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }
    }
}
