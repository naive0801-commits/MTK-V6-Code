using System;
using System.IO;
using System.Linq;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml;
using MtkFlashLib.Serial;
using MtkFlashLib.Utils;

namespace MtkFlashLib
{
    /// <summary>
    /// Preloader / BROM 工具类，负责硬件识别、鉴权令牌交互、寄存器读取以及高层刷机流程控制。
    /// </summary>
    public class PlTools
    {
        /// <summary>"OK" 响应字节</summary>
        public static readonly byte[] ByteOKs = AddOn.HexStringToBytes("4F 4B 00");
        /// <summary>"OK NOT-EXISTS" 响应字节</summary>
        public static readonly byte[] ByteNotExist = AddOn.HexStringToBytes("4F 4B 40 4E 4F 54 2D 45 58 49 53 54 53 00");

        private readonly MtkContext _context;
        private readonly MtkPort _port;
        private readonly SerialLib _serial;

        /// <summary>CPU 名称</summary>
        public string CpuName { get; private set; } = "";
        /// <summary>是否启用安全启动</summary>
        public bool SecureBoot { get; private set; } = false;
        /// <summary>芯片 ME-ID</summary>
        public string Meid { get; private set; } = "";
        /// <summary>芯片 SOC-ID</summary>
        public string SocId { get; private set; } = "";
        /// <summary>看门狗寄存器地址</summary>
        public int Watchdog { get; private set; } = 268464128;
        /// <summary>Preloader 大小设置</summary>
        public string PreloaderSizeSetting { get; private set; } = "";

        private string _doProcess = "";

        /// <summary>
        /// 构造函数，注入上下文、端口与串口库依赖。
        /// </summary>
        public PlTools(MtkContext context, MtkPort port, SerialLib serial)
        {
            _context = context;
            _port = port;
            _serial = serial;
        }

        /// <summary>
        /// 通过原生命令提示符安全地为 LibUsb 交互安装 USB 过滤驱动。
        /// </summary>
        public static void InstallFilterUSB(MtkContext context, string cmd)
        {
            try
            {
                // 根据操作系统位数选择对应的过滤驱动可执行文件
                string textExe = (!Environment.Is64BitOperatingSystem) ? "filter-x86.exe" : "filter-x64.exe";
                ProcessStartInfo startInfo = new ProcessStartInfo("data\\" + textExe, cmd)
                {
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden,
                    UseShellExecute = false,
                    Verb = "runas", // 以管理员权限运行
                    RedirectStandardError = true
                };

                using (Process process = Process.Start(startInfo))
                {
                    process?.WaitForExit();
                }
                context?.Log("USB 过滤驱动已执行，参数: " + cmd, MtkLogLevel.Info);
            }
            catch (Exception ex)
            {
                context?.Log("过滤驱动安装失败: " + ex.Message, MtkLogLevel.Warning);
            }
        }

        /// <summary>
        /// 从目标 BROM 通道直接读取自定义 32 位寄存器值。
        /// </summary>
        public byte[] Read32(string addressHex, int elements = 1)
        {
            // 下发读取命令、地址及读取元素个数
            _port.Echo("d1", 1);
            _port.Echo(addressHex, 4);
            _port.Echo(elements.ToString("X"), 4);

            // 读取并校验状态响应
            byte[] status = _serial.ReadUSB(2);
            _port.VerifyResponse(AddOn.BytesToHexString(status), "0000");

            // 逐个读取 4 字节寄存器值
            byte[] bytesOut = new byte[elements * 4];
            for (int i = 0; i < elements; i++)
            {
                byte[] res = _serial.ReadUSB(4);
                Buffer.BlockCopy(res, 0, bytesOut, i * 4, 4);
            }

            // 读取并校验结束状态
            status = _serial.ReadUSB(2);
            _port.VerifyResponse(AddOn.BytesToHexString(status), "0000");
            return bytesOut;
        }

        /// <summary>
        /// 执行自定义 Preloader 或 BROM 启动初始化流程。
        /// </summary>
        public bool BromBoot(string hwCode, byte[] payloadData = null)
        {
            try
            {
                _context?.Log("正在读取目标硬件标识...", MtkLogLevel.Info);
                GetHwConfiguration();

                if (!string.IsNullOrEmpty(PreloaderSizeSetting))
                {
                    _context.LoadedDa = "0x" + hwCode;
                }

                // 检查是否存在该 SOC 的硬件配置
                if (!BromConfig.HwConfig.ContainsKey(hwCode))
                {
                    _context?.Log("SOC " + hwCode + " 需要自定义 DA 架构", MtkLogLevel.Warning);
                    return false;
                }

                ChipConfig config = BromConfig.HwConfig[hwCode];
                Watchdog = config.Watchdog;

                // 处理安全启动场景下的鉴权流程
                if (SecureBoot)
                {
                    _context?.Log("当前 SOC 已启用安全启动。", MtkLogLevel.Warning);
                    if (_context.AutoAuthSv5)
                    {
                        // 根据芯片型号/工程名选择不同的鉴权服务
                        if (hwCode.Contains("1208") || _context.ProjectName == "tanzanite")
                        {
                            _context.ServiceId = 8;
                            if (!TokenOld()) return false;
                        }
                        else
                        {
                            _context.ServiceId = 11;
                            if (!TokenNew()) return false;
                        }
                    }
                }

                _context?.Log("SOC 同步并初始化完成，正在加载次级加载器...", MtkLogLevel.Success);
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("BromBoot 发生异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 向校验服务器发送自定义令牌挑战（例如 MTK 安全鉴权算法）。
        /// </summary>
        public bool TokenNew()
        {
            try
            {
                // 读取自定义鉴权文件
                byte[] authFile = File.Exists(_context.CustomAuthPath) ? File.ReadAllBytes(_context.CustomAuthPath) : Array.Empty<byte>();
                if (authFile.Length == 0)
                {
                    _context?.Log("未解析到有效的自定义鉴权文件。", MtkLogLevel.Error);
                    return false;
                }

                // 计算并发送经过补齐的鉴权结构长度
                string lenHex = MtkUtils.Penggenapan4Depan(authFile.Length.ToString("X"));
                _context?.Log("正在传输安全补齐的鉴权结构参数: " + lenHex, MtkLogLevel.Debug);

                _port.Echo("e2", 1);
                _port.WritePort(AddOn.HexStringToBytes(lenHex, _context));

                // 校验设备返回的长度是否与发送的一致
                byte[] reply = _serial.ReadUSB(4);
                if (AddOn.BytesToHexString(reply).ToUpper() != lenHex.ToUpper())
                {
                    _context?.Log("鉴权长度查询时校验回复不匹配: " + AddOn.BytesToHexString(reply), MtkLogLevel.Error);
                    return false;
                }

                // 发送鉴权文件并丢弃返回的 CRC
                _port.WritePort(authFile);
                _serial.ReadUSB(4); // 丢弃 CRC

                _context?.Log("鉴权签名挑战已成功处理并返回标准密钥。", MtkLogLevel.Success);
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("TokenNew 执行抛出异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 针对较旧 SOC 配置的令牌鉴权（布局映射与 TokenNew 相似）。
        /// </summary>
        public bool TokenOld()
        {
            // 与较旧 SOC 配置布局映射相似
            return TokenNew();
        }

        /// <summary>
        /// 向活动的 Preloader 连接发送崩溃命令字符串，强制进入 BROM 模式。
        /// </summary>
        public bool CrashPreloader()
        {
            _context?.Log("正在下发 BROM 崩溃序列负载块...", MtkLogLevel.Warning);
            byte[] crashPayload = new byte[100]; // 模拟代表崩溃脚本的负载结构
            return DaLegacyLib.SendDa(_context, _port, "0", crashPayload.Length.ToString("X"), "0", crashPayload);
        }

        /// <summary>
        /// 获取芯片 ID 信息及 SOC 相关变量（硬件代码、安全启动、ME-ID、SOC-ID 等）。
        /// </summary>
        public void GetHwConfiguration()
        {
            try
            {
                // 读取硬件代码
                _port.Echo("FD", 1);
                byte[] hwCodeBytes = _serial.ReadUSB(2);
                byte[] status = _serial.ReadUSB(2);

                // 读取硬件子代码、硬件版本、软件版本
                _port.Echo("fc", 1);
                byte[] hwSubCode = _serial.ReadUSB(2);
                byte[] hwVer = _serial.ReadUSB(2);
                byte[] swVer = _serial.ReadUSB(2);
                _serial.ReadUSB(2); // 丢弃状态

                // 读取目标配置以判断安全启动状态
                _port.Echo("d8", 1);
                byte[] targetConfig = _serial.ReadUSB(4);
                _serial.ReadUSB(2);

                // 配置二进制末位为 1 表示开启安全启动
                string configBin = Convert.ToString(Convert.ToInt32(AddOn.BytesToHexString(targetConfig), 16), 2);
                SecureBoot = configBin.EndsWith("1");

                CpuName = "0x" + AddOn.BytesToHexString(hwCodeBytes);
                _context?.Log($"目标硬件 SOC ID: {CpuName}, 软件版本: 0x{AddOn.BytesToHexString(swVer)}, 安全启动: {SecureBoot}", MtkLogLevel.Info);

                // 读取芯片 ME-ID
                _port.Echo("E1", 1);
                status = _serial.ReadUSB(4);
                if (status.Length > 0)
                {
                    int meIdLen = Convert.ToInt32(MtkUtils.HexToDec(AddOn.BytesToHexString(status)));
                    byte[] meIdBytes = _serial.ReadUSB(meIdLen);
                    Meid = AddOn.BytesToHexString(meIdBytes).ToUpper();
                    _context?.Log("芯片 ME-ID: " + Meid, MtkLogLevel.Info);
                }

                // 读取芯片 SOC-ID
                _port.Echo("E7", 1);
                status = _serial.ReadUSB(4);
                if (status.Length > 0)
                {
                    int socIdLen = Convert.ToInt32(MtkUtils.HexToDec(AddOn.BytesToHexString(status)));
                    byte[] socIdBytes = _serial.ReadUSB(socIdLen);
                    SocId = AddOn.BytesToHexString(socIdBytes).ToUpper();
                    _context?.Log("芯片 SOC-ID: " + SocId, MtkLogLevel.Info);
                }
            }
            catch (Exception ex)
            {
                _context?.Log("GetHwConfiguration 解析失败: " + ex.Message, MtkLogLevel.Error);
            }
        }

        /// <summary>
        /// 读取基于 XML 的刷机上下文中返回的 XML 响应。
        /// </summary>
        public bool ReadResponseXml(string contextInfo)
        {
            _doProcess = "";
            byte[] buffer = _serial.ReadUSB(12);

            if (buffer.Length > 0)
            {
                // 解析响应长度字段（小端，需反转）
                byte[] lenPart = buffer.Skip(8).ToArray();
                Array.Reverse(lenPart);

                string textLen = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(lenPart)));
                byte[] xmlBytes = _serial.ReadUSB(Convert.ToInt32(textLen));
                _doProcess = Encoding.UTF8.GetString(xmlBytes);

                // 检测 XML 中是否包含错误信息
                if (_doProcess.ToUpper().Contains("ERR"))
                {
                    _context?.Log($"XML 刷机错误: {_doProcess}", MtkLogLevel.Error);
                    XflashLib xflash = new XflashLib(_context, _port, _serial);
                    xflash.XSend(ByteOKs);
                    return false;
                }
                return true;
            }
            return false;
        }

        /// <summary>
        /// 发送 XML 刷机命令并读取返回状态。
        /// </summary>
        public bool SendCmdFlash(byte[] byteXml)
        {
            // 计算 XML 长度并附加魔术头后发送
            string hexLen = MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(byteXml.Length.ToString("X")));
            _port.WritePort(AddOn.HexStringToBytes("EFEEEEFE01000000" + hexLen, _context));
            _port.WritePort(byteXml);

            _serial.ReadUSB(12);
            byte[] status = _serial.ReadUSB(12);
            _doProcess = Encoding.UTF8.GetString(status);
            return true;
        }

        /// <summary>
        /// 面向较新 XML 布局的高层核心分区刷机自动化方法。
        /// </summary>
        public bool FlashUpdatev6(string xmlScatterPath, System.Collections.Generic.List<string> partitionNames, System.Collections.Generic.List<string> partitionFiles)
        {
            // 校验 XML scatter 文件是否存在
            if (!File.Exists(xmlScatterPath))
            {
                _context?.Log("指定的 XML scatter 文件路径不存在。", MtkLogLevel.Error);
                return false;
            }

            try
            {
                _context?.Log("正在处理 Flash Update 事务配置映射...", MtkLogLevel.Info);
                // 拼接待刷写分区列表参数
                string listPartitionsArg = "";
                for (int i = 0; i < partitionNames.Count; i++)
                {
                    if (File.Exists(partitionFiles[i]))
                    {
                        listPartitionsArg += $"<pt name=\"{partitionNames[i]}\">{partitionFiles[i]}</pt>";
                    }
                }

                // 构造 FLASH-UPDATE 命令 XML 并发送
                string cmdXml = $"<?xml version=\"1.0\" encoding=\"utf-8\"?><da><version>2.0</version><command>CMD:FLASH-UPDATE</command><arg><path_separator>\\</path_separator><source_file>{xmlScatterPath}</source_file><backup_folder>{_context.FolderSave}/temp/</backup_folder><flash_list>{listPartitionsArg}</flash_list></arg></da>";
                byte[] commandPayload = Encoding.UTF8.GetBytes(cmdXml);

                if (!SendCmdFlash(commandPayload)) return false;

                _context?.Log("正在按各分段顺序传输刷机数据块...", MtkLogLevel.Info);
                _context?.UpdateProgress("FLASH_UPDATE_SUCCESS", 100, 100, "所有分区均已成功完成。");
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("FlashUpdatev6 流程发生异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 发送第二个 DA（DA2）- V6 协议版本（支持 XML 命令与分块传输）。
        /// </summary>
        /// <param name="da2Data">DA2 二进制数据</param>
        /// <param name="useAlternateAddress">是否使用备用地址配置</param>
        public bool SendDa2v6(byte[] da2Data, bool useAlternateAddress = false)
        {
            try
            {
                ReadResponseXml("开始发送 DA2");
                XflashLib xflash = new XflashLib(_context, _port, _serial);
                xflash.XSend(ByteOKs);

                _context?.Log("发送 DA2: ", MtkLogLevel.Info);

                // 根据是否使用备用地址选择不同的启动配置 XML
                string bootXmlFile = useAlternateAddress ? "data/booto2.xml" : "data/booto.xml";
                
                // 发送启动 XML 命令（假设 SendCmdXml 方法存在或需要从文件读取）
                if (File.Exists(bootXmlFile))
                {
                    byte[] xmlCmd = File.ReadAllBytes(bootXmlFile);
                    if (!SendCmdFlash(xmlCmd))
                    {
                        _context?.Log("发送启动 XML 失败", MtkLogLevel.Error);
                        return false;
                    }
                }

                xflash.XSend(ByteOKs);

                // 发送 DA2 长度通知
                byte[] header = AddOn.HexStringToBytes("EF EE EE FE 01 00 00 00 0B 00 00 00", _context);
                _port.WritePort(header);

                string da2LenHex = MtkUtils.DecimalToHexadecimal(da2Data.Length);
                byte[] lenNotify = AddOn.HexStringToBytes("4F 4B 40 30 78" + AddOn.BytesToHexString(Encoding.UTF8.GetBytes(da2LenHex)) + "00", _context);
                _port.WritePort(lenNotify);

                ReadResponseXml("DA2 长度确认");

                // 分块发送 DA2 数据
                if (!SendDa2Xml(da2Data))
                {
                    _context?.Log("DA2 分块发送失败", MtkLogLevel.Error);
                    return false;
                }

                _doProcess = "";
                byte[] response = _serial.ReadUSB(12);
                if (response.Length > 0)
                {
                    byte[] lenBytes = response.Skip(8).ToArray();
                    Array.Reverse(lenBytes);
                    int respLen = Convert.ToInt32(MtkUtils.HexToDec(AddOn.BytesToHexString(lenBytes)));
                    byte[] respData = _serial.ReadUSB(respLen);
                    _doProcess = Encoding.UTF8.GetString(respData);
                }

                _context?.Log("DA2 发送完成", MtkLogLevel.Success);
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("SendDa2v6 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 以 XML 协议分块发送 DA2 数据（每块 4096 字节）。
        /// </summary>
        private bool SendDa2Xml(byte[] da2Data)
        {
            try
            {
                int daLength = da2Data.Length;
                int writtenLength = 0;
                int chunkSize = 4096;

                using (MemoryStream stream = new MemoryStream(da2Data))
                {
                    while (daLength > 0)
                    {
                        if (daLength < chunkSize)
                        {
                            chunkSize = daLength;
                        }

                        byte[] chunk = new byte[chunkSize];
                        int bytesRead = stream.Read(chunk, 0, chunkSize);
                        daLength -= bytesRead;
                        writtenLength += bytesRead;

                        // 发送块头
                        byte[] header = AddOn.HexStringToBytes("EF EE EE FE 01 00 00 00 07 00 00 00", _context);
                        _port.WritePort(header);

                        byte[] okMarker = AddOn.HexStringToBytes("4F 4B 40 30 78 30 00", _context);
                        _port.WritePort(okMarker);

                        // 读取响应确认
                        byte[] response = _serial.ReadUSB(12);
                        if (response.Length > 8)
                        {
                            int respLen = Convert.ToInt32(MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(response).Substring(16))));
                            _serial.ReadUSB(respLen);
                        }

                        // 发送数据块长度与数据
                        string chunkLenHex = MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(MtkUtils.DecimalToHexadecimal(chunk.Length)));
                        byte[] lengthHeader = AddOn.HexStringToBytes("EF EE EE FE 01 00 00 00 " + chunkLenHex, _context);
                        _port.WritePort(lengthHeader);
                        _port.WritePort(chunk);

                        // 更新进度
                        _context?.UpdateProgress("发送 DA2", writtenLength, da2Data.Length);

                        // 读取块确认响应
                        response = _serial.ReadUSB(12);
                        if (response.Length > 8)
                        {
                            int respLen = Convert.ToInt32(MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(response).Substring(16))));
                            _serial.ReadUSB(respLen);
                        }
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("SendDa2Xml 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 发送第二个 DA（DA2）- 传统协议版本（非 XML）。
        /// </summary>
        public bool SendDa2Legacy(byte[] da2Data)
        {
            try
            {
                XflashLib xflash = new XflashLib(_context, _port, _serial);
                
                // 发送查询命令
                xflash.XSend4(AddOn.HexStringToBytes("08 00 01 00", _context));
                byte[] status = _serial.ReadUSB(16);
                
                string magicHex = "EFEEEEFE"; // XflashLib 魔术头
                if (!AddOn.BytesToHexString(status).Contains(magicHex))
                {
                    _context?.Log("DA2 响应错误: " + AddOn.BytesToHexString(status), MtkLogLevel.Error);
                    return false;
                }

                // 发送 DA2 加载通知
                _port.WritePort(AddOn.HexStringToBytes("EF EE EE FE 01 00 00 00 10 00 00 00", _context));

                string da2LenHex = MtkUtils.DecimalToHexadecimal(da2Data.Length);
                string lenPayload = "0000004000000000" + AddOn.ApplyShiftKiri2(da2LenHex) + "0000000000";
                _port.WritePort(AddOn.HexStringToBytes(lenPayload, _context));

                _context?.Log("发送 DA2: ", MtkLogLevel.Info);

                // 发送 DA2 数据
                string finalHeader = magicHex + "10000000" + AddOn.ApplyShiftKiri2(da2LenHex) + "00";
                _port.WritePort(AddOn.HexStringToBytes(finalHeader, _context));
                _port.WritePort(da2Data);

                // 读取响应
                byte[] response = _serial.ReadUSB(16);
                if (AddOn.BytesToHexString(response).ToUpper().Contains("C0"))
                {
                    _context?.Log("DA2 发送失败: " + AddOn.BytesToHexString(response), MtkLogLevel.Error);
                    return false;
                }

                _context?.Log("DA2 发送成功", MtkLogLevel.Success);
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("SendDa2Legacy 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 发送 EMI（外部存储器接口）配置到设备。
        /// </summary>
        /// <param name="emiData">EMI 配置数据</param>
        public bool SendingEmi(byte[] emiData)
        {
            try
            {
                if (emiData == null || emiData.Length == 0)
                {
                    _context?.Log("EMI 数据为空，尝试从内部 EMI 库搜索...", MtkLogLevel.Warning);
                    
                    // 尝试从预定义路径加载 EMI 文件
                    string emiPath = Path.Combine(Directory.GetCurrentDirectory(), "preloader", "emi");
                    if (Directory.Exists(emiPath))
                    {
                        string[] emiFiles = Directory.GetFiles(emiPath);
                        foreach (string file in emiFiles)
                        {
                            byte[] testEmi = File.ReadAllBytes(file);
                            if (SendEmiInternal(testEmi))
                            {
                                _context?.Log("检测到有效的 EMI 配置: " + Path.GetFileName(file), MtkLogLevel.Success);
                                return true;
                            }
                        }
                    }

                    _context?.Log("未找到有效的 EMI 配置", MtkLogLevel.Error);
                    return false;
                }

                return SendEmiInternal(emiData);
            }
            catch (Exception ex)
            {
                _context?.Log("SendingEmi 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 内部 EMI 发送实现。
        /// </summary>
        private bool SendEmiInternal(byte[] emiData)
        {
            try
            {
                XflashLib xflash = new XflashLib(_context, _port, _serial);

                // 发送 EMI 加载命令
                xflash.XSend4(AddOn.HexStringToBytes("0A 00 01 00", _context));
                byte[] status = _serial.ReadUSB(24);
                _context?.Log("EMI 状态 1: " + AddOn.BytesToHexString(status), MtkLogLevel.Debug);

                // 发送 EMI 长度
                string emiLenHex = MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(MtkUtils.DecimalToHexadecimal(emiData.Length)));
                xflash.XSend(AddOn.HexStringToBytes(emiLenHex, _context));

                // 发送 EMI 数据
                _port.WritePort(AddOn.HexStringToBytes("EF EE EE FE 01 00 00 00 " + emiLenHex, _context));
                _port.WritePort(emiData);

                // 读取响应并验证
                status = _serial.ReadUSB(16);
                if (status.Length == 0)
                {
                    _context?.Log("EMI 响应超时 (0xFFFF)", MtkLogLevel.Error);
                    return false;
                }

                string statusHex = AddOn.BytesToHexString(status);
                if (statusHex.Length >= 32 && statusHex.Substring(30, 2) == "00")
                {
                    _context?.Log("EMI 配置已成功发送", MtkLogLevel.Success);
                    return true;
                }

                _context?.Log("EMI 发送错误: " + AddOn.ApplyShiftKiri2(statusHex.Substring(24)), MtkLogLevel.Error);
                return false;
            }
            catch (Exception ex)
            {
                _context?.Log("SendEmiInternal 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 从设备转储 Preloader 镜像（通过 BROM 读取 EMMC boot1 分区）。
        /// </summary>
        public bool RunDumpPreloader(string savePath = "preloader.bin")
        {
            try
            {
                _context?.Log("正在转储 Preloader...", MtkLogLevel.Info);

                // 发送读取命令 D1
                _port.WritePort(new byte[] { 0xD1 });
                byte[] response = _serial.ReadUSB(1);
                if (AddOn.BytesToHexString(response).ToUpper() != "D1")
                {
                    _context?.Log("Preloader 转储命令 (D1) 响应失败: " + AddOn.BytesToHexString(response), MtkLogLevel.Error);
                    return false;
                }

                // 发送读取地址与长度（0x00200000, 0x00400000 = 4MB）
                _port.WritePort(AddOn.HexStringToBytes("00 20 00 00", _context));
                _serial.ReadUSB(4);
                _port.WritePort(AddOn.HexStringToBytes("00 00 40 00", _context));
                _serial.ReadUSB(4);

                // 验证状态
                byte[] status = _serial.ReadUSB(2);
                if (AddOn.BytesToHexString(status).ToUpper() != "0000")
                {
                    _context?.Log("Preloader 转储状态错误: " + AddOn.BytesToHexString(status), MtkLogLevel.Error);
                    return false;
                }

                // 读取 64KB 数据块
                byte[] preloaderData = new byte[65536];
                using (MemoryStream ms = new MemoryStream(preloaderData))
                {
                    int totalRead = 0;
                    while (totalRead < 65536)
                    {
                        byte[] chunk = _serial.ReadUSB(4096);
                        ms.Write(chunk, 0, chunk.Length);
                        totalRead += chunk.Length;
                        _context?.UpdateProgress("转储 Preloader", totalRead, 65536);
                    }
                }

                // 验证结束状态
                status = _serial.ReadUSB(2);
                if (AddOn.BytesToHexString(status).ToUpper() != "0000")
                {
                    _context?.Log("Preloader 转储结束状态错误: " + AddOn.BytesToHexString(status), MtkLogLevel.Error);
                    return false;
                }

                // 保存到文件
                File.WriteAllBytes(savePath, preloaderData);
                _context?.Log("Preloader 已转储至: " + savePath, MtkLogLevel.Success);
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("RunDumpPreloader 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 执行安全绕过利用（通过 Payload 注入与控制传输触发）。
        /// </summary>
        /// <param name="config">芯片配置</param>
        /// <param name="payload">利用负载</param>
        public bool Exploit(ChipConfig config, byte[] payload)
        {
            try
            {
                _context?.Log("准备利用数据...", MtkLogLevel.Warning);

                // 配置看门狗与负载地址
                int watchdogAddr = config.Watchdog;
                string payloadAddrHex = config.BromPayloadAddr.ToString("X");

                // 将负载地址写入看门狗偏移位置
                string targetAddrHex = (watchdogAddr + 80).ToString("X");
                string payloadHex = AddOn.ApplyShiftKiri2(payloadAddrHex);
                _port.Write32(targetAddrHex, payloadHex);

                _context?.Log("正在触发利用序列...", MtkLogLevel.Info);

                // 执行 Read32 触发漏洞
                if (config.Var0.HasValue)
                {
                    long var0 = config.Var0.Value;
                    long readAddr = watchdogAddr + 80 - var0;
                    int readCount = (int)Math.Floor((var0 + 4.0) / 4.0);
                    Read32(readAddr.ToString("X"), readCount);
                }
                else
                {
                    // 默认触发序列
                    for (int i = 0; i <= 14; i++)
                    {
                        long readAddr = watchdogAddr + 80 - (15 - i) * 4;
                        Read32(readAddr.ToString("X"), 16 - i);
                    }
                }

                // 发送利用负载
                _port.Echo("e0", 1);
                _port.Echo(payload.Length.ToString("X"), 4);
                byte[] status = _serial.ReadUSB(2);
                _port.VerifyResponse(AddOn.BytesToHexString(status), "0000");

                _port.WritePort(payload);
                _serial.ReadUSB(4);

                _context?.Log("等待利用响应...", MtkLogLevel.Info);
                byte[] bypassResponse = _serial.ReadUSB(4);
                string responseHex = AddOn.BytesToHexString(bypassResponse).ToLower();

                if (responseHex == "a1a2a3a4" || responseHex.Contains("a3a4"))
                {
                    _context?.Log("利用成功!", MtkLogLevel.Success);
                    return true;
                }

                _context?.Log("利用失败，响应: " + responseHex, MtkLogLevel.Error);
                return false;
            }
            catch (Exception ex)
            {
                _context?.Log("Exploit 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 准备安全绕过负载（从配置中加载或生成）。
        /// </summary>
        public byte[] PreparePayload(ChipConfig config)
        {
            try
            {
                if (config.Loader != null && config.Loader.Length > 0)
                {
                    _context?.Log("已从芯片配置加载利用负载", MtkLogLevel.Info);
                    return config.Loader;
                }

                _context?.Log("未找到预定义负载", MtkLogLevel.Warning);
                return Array.Empty<byte>();
            }
            catch (Exception ex)
            {
                _context?.Log("PreparePayload 异常: " + ex.Message, MtkLogLevel.Error);
                return Array.Empty<byte>();
            }
        }

        /// <summary>
        /// 获取 MTK 芯片的 Blob 配置密钥（用于认证与解锁）。
        /// 此功能从设备读取两个 Token 数据块并组合成 Blob 密钥。
        /// </summary>
        /// <param name="blobKey">输出的 Blob 密钥（十六进制字符串）</param>
        /// <returns>是否成功获取 Blob 密钥</returns>
        public bool GetBlobKey(out string blobKey)
        {
            blobKey = "";
            
            try
            {
                _context?.Log("正在获取 Blob 配置密钥...", MtkLogLevel.Info);

                // 步骤 1: 发送初始化命令
                if (!_port.Send00000(16, "Blob 初始化命令 1", "09 00 01 00", "100"))
                {
                    _context?.Log("Blob 初始化命令 1 失败", MtkLogLevel.Error);
                    return false;
                }

                if (!_port.Send00000(16, "Blob 初始化命令 2", "0C 00 02 00", "100"))
                {
                    _context?.Log("Blob 初始化命令 2 失败", MtkLogLevel.Error);
                    return false;
                }

                // 步骤 2: 发送空数据包
                _port.WritePort(AddOn.HexStringToBytes("EF EE EE FE 01 00 00 00 00 00 00 00", _context));
                _serial.ReadUSB(16); // 读取响应并丢弃

                // 步骤 3: 请求 Blob 数据
                if (!_port.Send00000(16, "请求 Blob 数据 1", "09 00 01 00", "100"))
                {
                    _context?.Log("请求 Blob 数据失败", MtkLogLevel.Error);
                    return false;
                }

                if (!_port.Send00000(16, "请求 Blob 数据 2", "13 00 04 00", "100"))
                {
                    _context?.Log("请求 Blob 数据命令失败", MtkLogLevel.Error);
                    return false;
                }

                // 步骤 4: 读取 Blob 数据（68 字节）
                _serial.ReadUSB(12); // 跳过头部
                byte[] blobData = _serial.ReadUSB(68);
                
                if (blobData.Length < 68)
                {
                    _context?.Log($"Blob 数据长度不足: {blobData.Length} 字节，期望 68 字节", MtkLogLevel.Error);
                    return false;
                }

                // 步骤 5: 解析 Blob 数据
                string blobHex = AddOn.BytesToHexString(blobData);
                
                // 提取两个关键 Token（每个 32 个十六进制字符 = 16 字节）
                string token2 = blobHex.Substring(8, 32);   // 从偏移 4 字节开始，取 16 字节
                string token3 = blobHex.Substring(40, 32);  // 从偏移 20 字节开始，取 16 字节

                // 步骤 6: 组合 Blob 密钥（token3 + token2 的顺序）
                blobKey = token3 + token2;

                // 步骤 7: 发送确认命令
                if (!_port.Send00000(16, "Blob 确认命令 1", "09 00 01 00", "100"))
                {
                    _context?.Log("Blob 确认命令失败", MtkLogLevel.Warning);
                    // 继续执行，密钥已获取
                }

                if (!_port.Send00000(16, "Blob 确认命令 2", "16 00 04 00", "100"))
                {
                    _context?.Log("Blob 确认命令 2 失败", MtkLogLevel.Warning);
                    // 继续执行，密钥已获取
                }

                _serial.ReadUSB(16); // 读取确认响应
                _serial.ReadUSB(16); // 读取最终响应

                // 将 Blob 密钥保存到上下文
                _context.ConfigData = blobKey;

                _context?.Log($"Blob 密钥获取成功: {blobKey.Substring(0, Math.Min(16, blobKey.Length))}...", MtkLogLevel.Success);
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("GetBlobKey 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 获取 Blob 密钥并以 Base64 格式输出（用于外部工具）。
        /// </summary>
        /// <param name="base64BlobKey">输出的 Base64 编码 Blob 密钥</param>
        /// <returns>是否成功获取并编码</returns>
        public bool GetBlobKeyBase64(out string base64BlobKey)
        {
            base64BlobKey = "";
            
            if (!GetBlobKey(out string hexBlobKey))
            {
                return false;
            }

            try
            {
                // 将十六进制字符串转换为字节数组
                byte[] blobBytes = AddOn.HexStringToBytes(hexBlobKey, _context);
                
                // 转换为 Base64 编码
                base64BlobKey = Convert.ToBase64String(blobBytes);
                
                _context?.Log("Blob 密钥已编码为 Base64 格式", MtkLogLevel.Info);
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("Base64 编码失败: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 将 Blob 密钥保存到文件（支持十六进制和 Base64 两种格式）。
        /// </summary>
        /// <param name="filePath">保存文件路径</param>
        /// <param name="useBase64">是否使用 Base64 格式（默认为十六进制）</param>
        /// <returns>是否成功保存</returns>
        public bool SaveBlobKeyToFile(string filePath, bool useBase64 = false)
        {
            try
            {
                string blobKey;
                bool success;

                if (useBase64)
                {
                    success = GetBlobKeyBase64(out blobKey);
                }
                else
                {
                    success = GetBlobKey(out blobKey);
                }

                if (!success)
                {
                    return false;
                }

                // 写入文件
                File.WriteAllText(filePath, blobKey);
                
                _context?.Log($"Blob 密钥已保存至: {filePath} ({(useBase64 ? "Base64" : "十六进制")} 格式)", MtkLogLevel.Success);
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("保存 Blob 密钥失败: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 生成完整的认证配置数据（包含 SOC-ID 和 Blob 密钥）。
        /// 用于高级认证场景，生成格式: "0200000001340220" + SOCID + "0310" + BlobKey
        /// </summary>
        /// <param name="socId">SOC-ID（如果为空则使用当前读取的 SOC-ID）</param>
        /// <param name="configData">输出的完整配置数据</param>
        /// <returns>是否成功生成配置数据</returns>
        public bool GenerateAuthConfig(string socId, out string configData)
        {
            configData = "";
            
            try
            {
                // 如果未提供 SOC-ID，使用当前已读取的
                if (string.IsNullOrEmpty(socId))
                {
                    socId = SocId;
                }

                if (string.IsNullOrEmpty(socId))
                {
                    _context?.Log("SOC-ID 未知，请先调用 GetHwConfiguration", MtkLogLevel.Error);
                    return false;
                }

                // 获取 Blob 密钥
                if (!GetBlobKey(out string blobKey))
                {
                    return false;
                }

                // 组合认证配置数据
                // 格式: 头部 + SOC-ID + 中间标识 + BlobKey
                string authHeader = "0200000001340220";
                string midMarker = "0310";
                configData = authHeader + socId + midMarker + blobKey;

                _context?.Log($"认证配置数据已生成，长度: {configData.Length} 字符", MtkLogLevel.Success);
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("GenerateAuthConfig 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 生成认证配置数据并以 Base64 格式输出。
        /// </summary>
        /// <param name="socId">SOC-ID（如果为空则使用当前读取的 SOC-ID）</param>
        /// <param name="base64ConfigData">输出的 Base64 编码配置数据</param>
        /// <returns>是否成功生成并编码</returns>
        public bool GenerateAuthConfigBase64(string socId, out string base64ConfigData)
        {
            base64ConfigData = "";
            
            if (!GenerateAuthConfig(socId, out string hexConfigData))
            {
                return false;
            }

            try
            {
                byte[] configBytes = AddOn.HexStringToBytes(hexConfigData, _context);
                base64ConfigData = Convert.ToBase64String(configBytes);
                
                _context?.Log("认证配置数据已编码为 Base64 格式", MtkLogLevel.Info);
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("Base64 编码失败: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 将 Sig（签名认证数据）发送到设备，通过通讯加密验证后允许读写擦等操作。
        /// Sig 是通过外部认证工具基于 Blob 密钥计算得到的签名数据。
        /// 注意：这是 MTK 芯片通讯协议的安全验证，与设备 Bootloader 解锁无关。
        /// </summary>
        /// <param name="sigData">签名数据（十六进制字符串或字节数组）</param>
        /// <returns>是否成功发送并通过验证</returns>
        public bool SendSigAuth(byte[] sigData)
        {
            try
            {
                if (sigData == null || sigData.Length == 0)
                {
                    _context?.Log("Sig 数据为空", MtkLogLevel.Error);
                    return false;
                }

                _context?.Log($"正在发送 Sig 认证数据（长度: {sigData.Length} 字节）...", MtkLogLevel.Info);

                // 步骤 1: 发送认证初始化命令
                if (!_port.Send00000(16, "Sig 认证命令 1", "09 00 01 00", "100"))
                {
                    _context?.Log("Sig 认证初始化命令失败", MtkLogLevel.Error);
                    return false;
                }

                // 步骤 2: 发送认证准备命令
                if (!_port.Send00000(16, "Sig 认证命令 2", "0B 00 02 00", "100"))
                {
                    _context?.Log("Sig 认证准备命令失败", MtkLogLevel.Error);
                    return false;
                }

                // 步骤 3: 发送 Sig 数据长度头部（256 字节固定长度 = 0x0100）
                byte[] lengthHeader = AddOn.HexStringToBytes("EF EE EE FE 01 00 00 00 00 01 00 00", _context);
                _port.WritePort(lengthHeader);

                // 步骤 4: 发送 Sig 数据（如果不足 256 字节则填充）
                byte[] paddedSigData = new byte[256];
                Buffer.BlockCopy(sigData, 0, paddedSigData, 0, Math.Min(sigData.Length, 256));
                _port.WritePort(paddedSigData);

                // 步骤 5: 读取设备响应
                byte[] response = _serial.ReadUSB(16);
                string responseHex = AddOn.BytesToHexString(response);

                // 检查响应最后一个字节是否为 00（表示成功）
                if (responseHex.Length >= 2 && responseHex.Substring(responseHex.Length - 2, 2).ToUpper() == "00")
                {
                    _context?.Log("✓ Sig 认证成功，设备已通过通讯加密验证，可进行读写擦操作", MtkLogLevel.Success);
                    return true;
                }
                else
                {
                    _context?.Log($"Sig 认证失败，响应: {responseHex}", MtkLogLevel.Error);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _context?.Log("SendSigAuth 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 将 Sig（签名认证数据）发送到设备（十六进制字符串版本）。
        /// </summary>
        /// <param name="sigHexString">签名数据的十六进制字符串</param>
        /// <returns>是否成功发送并通过验证</returns>
        public bool SendSigAuth(string sigHexString)
        {
            try
            {
                if (string.IsNullOrEmpty(sigHexString))
                {
                    _context?.Log("Sig 十六进制字符串为空", MtkLogLevel.Error);
                    return false;
                }

                // 将十六进制字符串转换为字节数组
                byte[] sigData = AddOn.HexStringToBytes(sigHexString, _context);
                return SendSigAuth(sigData);
            }
            catch (Exception ex)
            {
                _context?.Log("SendSigAuth (字符串) 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 从文件加载 Sig 数据并发送到设备。
        /// 支持十六进制文本文件和二进制文件。
        /// </summary>
        /// <param name="sigFilePath">Sig 数据文件路径</param>
        /// <param name="isBinary">是否为二进制文件（false 表示十六进制文本）</param>
        /// <returns>是否成功加载并发送</returns>
        public bool SendSigAuthFromFile(string sigFilePath, bool isBinary = false)
        {
            try
            {
                if (!File.Exists(sigFilePath))
                {
                    _context?.Log($"Sig 文件不存在: {sigFilePath}", MtkLogLevel.Error);
                    return false;
                }

                byte[] sigData;

                if (isBinary)
                {
                    // 直接读取二进制文件
                    sigData = File.ReadAllBytes(sigFilePath);
                    _context?.Log($"已从二进制文件加载 Sig: {sigFilePath}", MtkLogLevel.Info);
                }
                else
                {
                    // 读取十六进制文本文件
                    string hexString = File.ReadAllText(sigFilePath).Trim();
                    sigData = AddOn.HexStringToBytes(hexString, _context);
                    _context?.Log($"已从十六进制文件加载 Sig: {sigFilePath}", MtkLogLevel.Info);
                }

                return SendSigAuth(sigData);
            }
            catch (Exception ex)
            {
                _context?.Log("SendSigAuthFromFile 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 完整的 Blob + Sig 认证流程（自动化）。
        /// 1. 获取 Blob 密钥
        /// 2. 生成认证配置
        /// 3. 调用外部认证工具计算 Sig
        /// 4. 发送 Sig 到设备进行通讯加密验证
        /// 注意：此流程用于 MTK 芯片通讯协议安全验证，与设备 Bootloader 解锁无关。
        /// </summary>
        /// <param name="authToolPath">外部认证工具路径（留空则仅获取 Blob 和配置）</param>
        /// <param name="sigOutputPath">Sig 输出文件路径（用于接收认证工具的输出）</param>
        /// <returns>是否完成整个认证流程</returns>
        public bool PerformFullBlobSigAuth(string authToolPath = "", string sigOutputPath = "auth.bin")
        {
            try
            {
                _context?.Log("=== 开始完整 Blob + Sig 通讯加密验证流程 ===", MtkLogLevel.Info);

                // 步骤 1: 获取 Blob 密钥
                _context?.Log("步骤 1/4: 获取 Blob 密钥", MtkLogLevel.Info);
                if (!GetBlobKey(out string blobKey))
                {
                    _context?.Log("获取 Blob 密钥失败", MtkLogLevel.Error);
                    return false;
                }
                _context?.Log($"✓ Blob 密钥: {blobKey.Substring(0, Math.Min(16, blobKey.Length))}...", MtkLogLevel.Success);

                // 步骤 2: 生成认证配置
                _context?.Log("步骤 2/4: 生成认证配置", MtkLogLevel.Info);
                if (!GenerateAuthConfig("", out string authConfig))
                {
                    _context?.Log("生成认证配置失败", MtkLogLevel.Error);
                    return false;
                }

                // 保存认证配置到文件供外部工具使用
                string configPath = "config.bin";
                File.WriteAllText(configPath, authConfig);
                _context?.Log($"✓ 认证配置已保存: {configPath}", MtkLogLevel.Success);

                // 步骤 3: 如果提供了认证工具路径，则调用它
                if (!string.IsNullOrEmpty(authToolPath) && File.Exists(authToolPath))
                {
                    _context?.Log("步骤 3/4: 调用外部认证工具计算 Sig", MtkLogLevel.Info);
                    
                    var processInfo = new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = authToolPath,
                        Arguments = $"\"{configPath}\" \"{sigOutputPath}\"",
                        UseShellExecute = false,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true,
                        CreateNoWindow = true
                    };

                    using (var process = System.Diagnostics.Process.Start(processInfo))
                    {
                        process.WaitForExit();
                        
                        if (process.ExitCode != 0)
                        {
                            string error = process.StandardError.ReadToEnd();
                            _context?.Log($"认证工具执行失败: {error}", MtkLogLevel.Error);
                            return false;
                        }
                    }

                    _context?.Log("✓ 认证工具执行完成", MtkLogLevel.Success);

                    // 步骤 4: 发送 Sig 到设备
                    _context?.Log("步骤 4/4: 发送 Sig 到设备进行通讯验证", MtkLogLevel.Info);
                    
                    if (!File.Exists(sigOutputPath))
                    {
                        _context?.Log($"Sig 文件未生成: {sigOutputPath}", MtkLogLevel.Error);
                        return false;
                    }

                    if (!SendSigAuthFromFile(sigOutputPath, isBinary: false))
                    {
                        _context?.Log("发送 Sig 到设备失败", MtkLogLevel.Error);
                        return false;
                    }

                    _context?.Log("=== Blob + Sig 通讯加密验证流程完成，设备已允许读写擦操作 ===", MtkLogLevel.Success);
                    return true;
                }
                else
                {
                    _context?.Log("未提供认证工具路径，仅完成 Blob 提取和配置生成", MtkLogLevel.Warning);
                    _context?.Log($"请使用认证工具处理 {configPath}，然后调用 SendSigAuth() 发送结果", MtkLogLevel.Info);
                    return true;
                }
            }
            catch (Exception ex)
            {
                _context?.Log("PerformFullBlobSigAuth 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 验证设备是否已通过 Sig 认证并处于可读写状态。
        /// 通过尝试执行一个简单的查询命令来验证通讯加密验证是否成功。
        /// </summary>
        /// <returns>设备是否已通过通讯验证并可进行读写擦操作</returns>
        public bool IsDeviceAuthenticatedAndReady()
        {
            try
            {
                _context?.Log("正在验证设备通讯加密验证状态...", MtkLogLevel.Info);

                // 尝试发送一个简单的查询命令
                if (_port.Send00000(16, "设备状态查询", "09 00 01 00", "100"))
                {
                    _context?.Log("✓ 设备已通过 Sig 认证，当前处于可读写状态", MtkLogLevel.Success);
                    return true;
                }
                else
                {
                    _context?.Log("设备未通过 Sig 认证或通信失败", MtkLogLevel.Warning);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _context?.Log("IsDeviceAuthenticatedAndReady 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }
    }
}
