using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace MtkFlashLib
{
    /// <summary>
    /// 通用辅助工具类，提供十六进制字符串处理、字节转换、加密以及补位等底层操作。
    /// </summary>
    public class AddOn
    {
        /// <summary>
        /// 对十六进制字符串配置块进行填充，使其按 16 字节边界对齐（类似 PKCS7 填充）。
        /// </summary>
        public static string PenambahanHexBytes(string inputHex)
        {
            // 计算字节长度（每两个十六进制字符代表一个字节）
            double len = (double)inputHex.Length / 2.0;
            double maxMatches = len / 16.0;
            // 计算与 16 字节对齐所需补足的余数
            double remainder = (0.0 - Math.Floor(0.0 - maxMatches)) * 16.0 - len;

            // 当数据已对齐时，追加一整块 16 字节填充
            if (remainder == 0.0)
            {
                return inputHex + "10101010101010101010101010101010";
            }
            // 根据缺失字节数追加对应的 PKCS7 风格填充值
            if (remainder == 1.0) return inputHex + "01";
            if (remainder == 2.0) return inputHex + "0202";
            if (remainder == 3.0) return inputHex + "030303";
            if (remainder == 4.0) return inputHex + "04040404";
            if (remainder == 5.0) return inputHex + "0505050505";
            if (remainder == 6.0) return inputHex + "060606060606";
            if (remainder == 7.0) return inputHex + "07070707070707";
            if (remainder == 8.0) return inputHex + "0808080808080808";
            if (remainder == 9.0) return inputHex + "090909090909090909";
            if (remainder == 10.0) return inputHex + "0a0a0a0a0a0a0a0a0a0a";
            if (remainder == 11.0) return inputHex + "0b0b0b0b0b0b0b0b0b0b0b";
            if (remainder == 12.0) return inputHex + "0c0c0c0c0c0c0c0c0c0c0c0c";
            if (remainder == 13.0) return inputHex + "0d0d0d0d0d0d0d0d0d0d0d0d0d";
            if (remainder == 14.0) return inputHex + "0e0e0e0e0e0e0e0e0e0e0e0e0e0e";
            if (remainder == 15.0) return inputHex + "0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f";
            if (remainder == 16.0) return inputHex + "10101010101010101010101010101010";

            return inputHex;
        }

        /// <summary>
        /// 将十六进制字符串配置块转换为原始字节数组。
        /// </summary>
        public static byte[] HexStringToBytes(string s, MtkContext context = null)
        {
            try
            {
                // 去除空格与换行符等无关字符
                s = s.Replace(" ", "").Replace("\r", "").Replace("\n", "");
                int num = s.Length / 2;
                byte[] bytes = new byte[num];
                // 每两个字符解析为一个字节
                for (int i = 0; i < num; i++)
                {
                    bytes[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
                }
                return bytes;
            }
            catch (Exception ex)
            {
                context?.Log("HexStringToBytes 转换错误: " + ex.Message, MtkLogLevel.Error);
                return Array.Empty<byte>();
            }
        }

        /// <summary>
        /// 将原始字节数组转换为小写十六进制字符串。
        /// </summary>
        public static string BytesToHexString(byte[] input)
        {
            return BitConverter.ToString(input).Replace("-", "").ToLower();
        }

        /// <summary>
        /// 使用 Rijndael 算法以 CBC 模式进行标准分组加密。
        /// </summary>
        public static byte[] EncrptorCuk(byte[] cipherText, byte[] key, byte[] iv, MtkContext context = null)
        {
            try
            {
                using (Aes algo = Aes.Create())
                {
                    // 配置 AES 参数：128 位分组、CBC 模式、无填充
                    algo.BlockSize = 128;
                    algo.FeedbackSize = 128;
                    algo.KeySize = 128;
                    algo.Mode = CipherMode.CBC;
                    algo.IV = iv;
                    algo.Key = key;
                    algo.Padding = PaddingMode.None;

                    byte[] buffOut = new byte[cipherText.Length];
                    using (ICryptoTransform encryptor = algo.CreateEncryptor())
                    using (MemoryStream streamInput = new MemoryStream(cipherText))
                    using (MemoryStream streamOutput = new MemoryStream(buffOut))
                    using (CryptoStream cryptoStream = new CryptoStream(streamOutput, encryptor, CryptoStreamMode.Write))
                    {
                        // 分块读取明文并写入加密流
                        byte[] buffer = new byte[128];
                        int bytesRead;
                        while ((bytesRead = streamInput.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            cryptoStream.Write(buffer, 0, bytesRead);
                        }
                    }
                    return buffOut;
                }
            }
            catch (Exception ex)
            {
                context?.Log("EncrptorCuk 加密算法错误: " + ex.Message, MtkLogLevel.Error);
                return Array.Empty<byte>();
            }
        }

        /// <summary>
        /// 对十六进制字符串进行长度补齐，确保满足分组大小要求（保证偶数长度）。
        /// </summary>
        public static string Digenapin(string input)
        {
            // 若长度为奇数则在前面补 0
            if (input.Length % 2 == 1)
            {
                input = "0" + input;
            }
            return input;
        }

        /// <summary>
        /// 对 URL 组件进行编码，并将转义序列统一为大写 ASCII，以满足签名安全校验要求。
        /// </summary>
        public static string EncodeURL(string input)
        {
            string encoded = HttpUtility.UrlEncode(input);
            // 将 %xx 转义序列统一转换为大写形式
            return Regex.Replace(encoded, "%[a-f0-9]{2}", m => m.Value.ToUpperInvariant());
        }

        /// <summary>
        /// 将十六进制字符串从小端布局转换格式（字节序反转）。
        /// </summary>
        public static string ApplyShiftKiri2(string hexString)
        {
            string output = "";
            // 保证十六进制字符串为偶数长度
            if (hexString.Length % 2 != 0)
            {
                hexString = "0" + hexString;
            }

            // 从末尾开始按字节逆序拼接，实现字节序反转
            int count = hexString.Length - 2;
            double loops = (double)hexString.Length / 2.0 - 1.0;

            for (double i = 0.0; i <= loops; i += 1.0)
            {
                output += hexString.Substring(count, 2);
                count -= 2;
            }

            // 去除前导 0 并保证偶数长度
            output = Regex.Replace(output, "^0+", "");
            if (output.Length % 2 != 0)
            {
                output = "0" + output;
            }

            // 按原始长度在前面补足 00，保持总字节数一致
            double margin = (double)hexString.Length / 2.0 - (double)output.Length / 2.0 - 1.0;
            for (double zz = 0.0; zz <= margin; zz += 1.0)
            {
                output = "00" + output;
            }
            return output;
        }
    }
}
