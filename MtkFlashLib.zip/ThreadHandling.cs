using System;
using System.IO;
using System.Linq;
using System.Threading;
using MtkFlashLib.Serial;
using MtkFlashLib.Utils;

namespace MtkFlashLib
{
    /// <summary>
    /// 线程处理与刷机流程编排类，负责 Xflash 启动、分区表校验/重建及批量刷写控制。
    /// </summary>
    public class ThreadHandling
    {
        private readonly MtkContext _context;
        private readonly MtkPort _port;
        private readonly SerialLib _serial;
        private readonly XflashLib _xflash;
        private readonly PlTools _plTools;

        // 标记 PGPT 分区表是否已在预处理阶段重建
        private bool _udhRebuiltGppt = false;

        /// <summary>
        /// 构造函数，初始化依赖并创建 Xflash 与 PlTools 实例。
        /// </summary>
        public ThreadHandling(MtkContext context, MtkPort port, SerialLib serial)
        {
            _context = context;
            _port = port;
            _serial = serial;
            _xflash = new XflashLib(context, port, serial);
            _plTools = new PlTools(context, port, serial);
        }

        /// <summary>
        /// 启动 Xflash 流程，扫描分区表并提取 GPT 映射字段。
        /// </summary>
        public void BootXflash()
        {
            _context?.Log("正在初始化 Xflash 分区表扫描...", MtkLogLevel.Info);

            _xflash.GetEmmcInfoBrom();
            _context?.Log("磁盘边界解析完成，正在提取 GPT 映射字段...", MtkLogLevel.Success);
        }

        /// <summary>
        /// 校验已连接存储介质上的主/备分区方案，若发现损坏则进行重建。
        /// </summary>
        public void PgptCheck()
        {
            _context?.Log("正在审查主分区系统表（PGPT）...", MtkLogLevel.Info);
            string targetPath = Path.Combine(_context.FolderSave, "PGPT.bin");

            if (File.Exists(targetPath)) File.Delete(targetPath);

            // 备份 PGPT 分区到本地文件
            _xflash.BackupPartition("PGPT", targetPath);
            if (!File.Exists(targetPath) || new FileInfo(targetPath).Length == 0)
            {
                _context?.Log("主分区表块为空或无法访问。", MtkLogLevel.Warning);
                RebuildPgptTable();
                return;
            }

            // 解析备份的 GPT 数据并校验有效性
            byte[] gptBytes = File.ReadAllBytes(targetPath);
            MediatekGpt parsedGpt = new MediatekGpt();

            if (!Gpt.ParseGPT(gptBytes, _xflash.StorageType, parsedGpt))
            {
                _context?.Log("目标存储分区表为空或缺少有效签名。", MtkLogLevel.Warning);
                RebuildPgptTable();
            }
            else
            {
                _context?.Log("审查完成，分区结构对齐正常。", MtkLogLevel.Success);
            }
        }

        /// <summary>
        /// 基于模板 scatter 定义生成并写入新的主分区表块。
        /// </summary>
        private void RebuildPgptTable()
        {
            _context?.Log("正在基于模板 scatter 定义生成新的主分区表块...", MtkLogLevel.Info);
            byte[] pgptBytes = Gpt.BuildPgpt(contextBoxWrap(), _xflash.StorageSize);

            if (_xflash.WriteByPartitionName("PGPT", pgptBytes))
            {
                _context?.Log("主分区表块已成功在目标存储上重建。", MtkLogLevel.Success);
                _udhRebuiltGppt = true;
            }
            else
            {
                _context?.Log("重写分区表块失败。", MtkLogLevel.Error);
            }
        }

        /// <summary>
        /// XFLASH 模式下针对 eMMC / UFS 存储写入的高层刷机脚本处理主循环。
        /// </summary>
        public bool FlashMtkXflash(System.Collections.Generic.List<string> partitionNames, System.Collections.Generic.List<string> imagePaths)
        {
            _udhRebuiltGppt = false;
            _context?.Log("正在加载刷机镜像目标，数量: " + partitionNames.Count, MtkLogLevel.Info);

            try
            {
                for (int i = 0; i < partitionNames.Count; i++)
                {
                    string partName = partitionNames[i].Replace(" ", "");
                    string imagePath = imagePaths[i];

                    // 特殊处理 preloader 分区，需同时写入主分区与备份分区
                    if (partName.ToLower().Contains("preloader"))
                    {
                        _context?.Log($"正在刷写次级加载器 '{partName}'...", MtkLogLevel.Info);
                        if (_xflash.WriteByPartitionName("preloader", File.ReadAllBytes(imagePath)))
                        {
                            _xflash.WriteByPartitionName("preloader_backup", File.ReadAllBytes(imagePath));
                            continue;
                        }
                        _context?.Log("刷写 preloader 数据块失败。", MtkLogLevel.Error);
                        return false;
                    }

                    // 若 PGPT 已在预处理阶段配置完成则跳过
                    if (_udhRebuiltGppt && partName.ToUpper() == "PGPT")
                    {
                        _context?.Log("PGPT 已在预处理中配置，跳过。", MtkLogLevel.Info);
                        continue;
                    }

                    _context?.Log($"正在向逻辑分区 '{partName}' 刷写负载...", MtkLogLevel.Info);
                    if (!_xflash.WriteByPartitionName(partName, imagePath))
                    {
                        _context?.Log($"分区 '{partName}' 刷写失败，停止批量序列。", MtkLogLevel.Error);
                        return false;
                    }
                }

                // 全部刷写完成后根据配置自动重启设备
                if (_context.AutoReboot)
                {
                    RebootDevice();
                }

                _context?.Log("已成功完成所有选定目标的批量写入操作。", MtkLogLevel.Success);
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("FlashMtkXflash 通用错误: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 通过硬件寄存器触发看门狗复位序列以重启设备。
        /// </summary>
        public void RebootDevice()
        {
            _context?.Log("正在触发硬件寄存器上的看门狗复位序列...", MtkLogLevel.Warning);
            _port.WritePort(AddOn.HexStringToBytes("EFEEEEFE0100000004000000", _context));
            _port.WritePort(AddOn.HexStringToBytes("07000100", _context));
            Thread.Sleep(100);

            _serial.ReadUSB(16);
            _port.WritePort(AddOn.HexStringToBytes("EFEEEEFE0100000018000000", _context));
            _port.WritePort(AddOn.HexStringToBytes("01000000B80B000000000000000000000000000000000000", _context));
            _context?.Log("设备重启已启动。", MtkLogLevel.Info);
        }

        /// <summary>
        /// 上下文包装辅助方法，返回当前 MtkContext 实例。
        /// </summary>
        private MtkContext contextBoxWrap()
        {
            return _context;
        }
    }
}
