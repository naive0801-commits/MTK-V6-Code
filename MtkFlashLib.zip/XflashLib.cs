using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using MtkFlashLib.Serial;
using MtkFlashLib.Utils;

namespace MtkFlashLib
{
    /// <summary>
    /// XFLASH 模式核心库，负责获取存储信息、按分区名写入/转储数据、格式化扇区及环境握手等操作。
    /// </summary>
    public class XflashLib
    {
        /// <summary>数据流魔术头（带 01 命令）</summary>
        public static readonly string MagicHexFlow = "efeeeefe01000000";
        /// <summary>消息魔术头（带 02 命令）</summary>
        public static readonly string MagicHexMessage = "efeeeefe02000000";
        /// <summary>基础魔术标识</summary>
        public static readonly string MagicHex = "efeeeefe";

        private readonly MtkContext _context;
        private readonly MtkPort _port;
        private readonly SerialLib _serial;

        /// <summary>
        /// 存储容量大小（十六进制字符串）
        /// </summary>
        public string StorageSize { get; private set; } = "";
        
        /// <summary>
        /// 存储介质类型（emmc / ufs）
        /// </summary>
        public string StorageType { get; private set; } = "emmc";
        
        /// <summary>
        /// eMMC RPMB 区域大小
        /// </summary>
        public string EmmcRpmb { get; private set; } = "";
        
        /// <summary>
        /// RPMB 大小（整数，单位：块）
        /// </summary>
        public int RpmbSizeBlocks { get; private set; } = 0;

        /// <summary>
        /// 构造函数，注入上下文、端口与串口库依赖。
        /// </summary>
        public XflashLib(MtkContext context, MtkPort port, SerialLib serial)
        {
            _context = context;
            _port = port;
            _serial = serial;
        }

        /// <summary>
        /// 以固定 4 字节长度前缀发送数据块。
        /// </summary>
        public void XSend4(byte[] data)
        {
            _port.WritePort(AddOn.HexStringToBytes("EFEEEEFE0100000004000000", _context));
            _port.WritePort(data);
        }

        /// <summary>
        /// 根据数据长度自动计算并附加长度前缀后发送数据块。
        /// </summary>
        public void XSend(byte[] data)
        {
            // 计算数据长度的十六进制表示并补齐为偶数位
            string hexLen = data.Length.ToString("X");
            string padded = (hexLen.Length % 2 == 0) ? hexLen : "0" + hexLen;
            // 根据长度位数补足到 4 字节前缀
            string prefix = padded.Length == 2 ? padded + "000000" : (padded.Length == 4 ? padded + "0000" : (padded.Length == 6 ? padded + "00" : padded));
            
            _port.WritePort(AddOn.HexStringToBytes(MagicHexFlow + prefix, _context));
            _port.WritePort(data);
        }

        /// <summary>
        /// 从 MTK BROM 状态中读取闪存存储描述符映射信息（区分 eMMC 与 UFS）。
        /// </summary>
        public bool GetEmmcInfoBrom()
        {
            try
            {
                // 下发一系列初始化命令以查询存储信息
                _port.Send00000(16, "Get EmmInfo", "09 00 01 00", "100");
                _port.Send00000(16, "Get EmmInfo 2", "02 00 02 00", "100");
                _port.Send00000(16, "Get EmmInfo 3", "02 00 00 00", "100");
                _port.Send00000(16, "Get EmmInfo 4", "09 00 01 00", "100");
                _port.Send00000(16, "Get EmmInfo 4b", "03 00 02 00", "100");
                _port.Send00000(16, "Get EmmInfo 5", "02 00 00 00", "100");
                _port.Send00000(16, "Get EmmInfo 5b", "09 00 01 00", "100");
                _port.Send00000(16, "Get EmmInfo 6", "0A 00 04 00", "100");

                // 读取连接核心模式
                byte[] d = _serial.ReadUSB(16);
                string connectionMode = Encoding.UTF8.GetString(d.Skip(Math.Max(0, d.Length - 4)).ToArray());
                _context?.Log("连接核心模式: " + connectionMode, MtkLogLevel.Info);

                _serial.ReadUSB(16);
                _port.Send00000(16, "Get EmmInfo 7", "09 00 01 00", "100");
                _port.Send00000(16, "Get EmmInfo 7b", "0B000400", "100");
                // 读取 USB 高速模式信息
                byte[] khhh = _serial.ReadUSB(22);
                _context?.Log("USB 高速模式: " + Encoding.UTF8.GetString(khhh.Skip(12).ToArray()), MtkLogLevel.Info);

                _serial.ReadUSB(16);
                _port.Send00000(16, "Get EmmInfo 8", "09 00 01 00", "100");
                XSend4(AddOn.HexStringToBytes("0C000400", _context));
                Thread.Sleep(100);

                // 校验响应是否包含魔术标识
                string statusReply = AddOn.BytesToHexString(_serial.ReadUSB(24));
                if (!statusReply.Contains(MagicHex))
                {
                    _context?.Log("GetEmmcInfoBrom 响应错误: " + statusReply, MtkLogLevel.Error);
                    return false;
                }

                _serial.ReadUSB(24);
                _serial.ReadUSB(48);
                _port.Send00000(16, "Get Emmc Info Final", "09 00 01 00", "100");
                _port.Send00000(16, "Get Emmc Info Final 2", "01 00 04 00", "100");
                _serial.ReadUSB(12);
                byte[] emmcInfoBuff = _serial.ReadUSB(104);

                // 检查前 6 字节是否为全 0，以区分 eMMC 与 UFS
                string checkingBlock = AddOn.BytesToHexString(emmcInfoBuff.Take(6).ToArray()).Replace(" ", "");
                if (checkingBlock != "000000000000")
                {
                    // eMMC 存储分支
                    StorageType = "emmc";
                    _context?.Log("检测到存储介质布局: eMMC", MtkLogLevel.Success);
                    string emmcBlockSize = AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(emmcInfoBuff.Take(8).ToArray()));
                    string emmcBoot1 = AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(emmcInfoBuff.Skip(8).Take(8).ToArray()));
                    string emmcBoot2 = AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(emmcInfoBuff.Skip(16).Take(8).ToArray()));
                    EmmcRpmb = AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(emmcInfoBuff.Skip(24).Take(8).ToArray()));

                    _context?.Log($"[eMMC] 块大小: {emmcBlockSize}, Boot1 大小: {emmcBoot1}, Boot2 大小: {emmcBoot2}, RPMB 大小: {EmmcRpmb}", MtkLogLevel.Info);
                    _context.PreloaderFile = new byte[Convert.ToInt32(MtkUtils.HexToDec(emmcBoot1))];

                    StorageSize = AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(emmcInfoBuff.Skip(64).Take(8).ToArray()));
                    _context?.Log($"用户数据区大小: {StorageSize}", MtkLogLevel.Info);
                }
                else
                {
                    // UFS 存储分支
                    StorageType = "ufs";
                    _context?.Log("检测到存储介质布局: UFS", MtkLogLevel.Success);
                    _port.Send00000(16, "cmd env ufs", "09 00 01 00", "100");
                    XSend(AddOn.HexStringToBytes("04000400", _context));
                    Thread.Sleep(100);

                    _serial.ReadUSB(16);
                    _serial.ReadUSB(16);
                    _serial.ReadUSB(12);
                    byte[] ufsInfoBuff = _serial.ReadUSB(208);

                    string ufsType = AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(ufsInfoBuff.Take(4).ToArray()));
                    string ufsBlock = AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(ufsInfoBuff.Skip(4).Take(4).ToArray()));
                    string lu0 = AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(ufsInfoBuff.Skip(24).Take(8).ToArray()));
                    StorageSize = lu0;

                    _context?.Log($"[UFS] 配置: {ufsType}, 块大小: {ufsBlock}, LU0 区域大小: {lu0}", MtkLogLevel.Info);
                }
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("GetEmmcInfoBrom 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 将原始字节数据写入指定名称的目标分区，并正确计算与更新数据块校验和。
        /// </summary>
        public bool WriteByPartitionName(string partName, byte[] payload)
        {
            // 下发写入初始化命令
            if (!_port.Send00000(16, "Write Part format", "09 00 01 00", "100")) return false;
            if (!_port.Send00000(16, "Write register", "07 00 04 00", "100")) return false;

            _serial.ReadUSB(20);
            int pktLen = 1048576 * 2; // 写入块大小
            _serial.ReadUSB(16);

            if (!_port.Send00000(16, "Write byname header", "01 00 01 00", "100")) return false;

            // 发送分区名称长度及名称
            string hexNameLen = MtkUtils.Penggenapan4Belakang(partName.Length.ToString("X"));
            _port.WritePort(AddOn.HexStringToBytes("EFEEEEFE01000000" + hexNameLen, _context));
            _port.WritePort(Encoding.UTF8.GetBytes(partName));

            // 发送负载总长度
            string hexPayloadLen = MtkUtils.Penggenapan8(MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(payload.Length.ToString("X"))));
            XSend8(AddOn.HexStringToBytes(hexPayloadLen, _context));
            Thread.Sleep(100);

            _serial.ReadUSB(16);
            if (payload.Length <= pktLen)
            {
                pktLen = payload.Length;
            }

            // 分块写入负载数据
            using (MemoryStream stream = new MemoryStream(payload))
            {
                int totalWritten = 0;
                Stopwatch watch = Stopwatch.StartNew();

                while (totalWritten < payload.Length)
                {
                    int currentChunkSize = Math.Min(payload.Length - totalWritten, pktLen);
                    byte[] chunk = new byte[currentChunkSize];
                    stream.Read(chunk, 0, currentChunkSize);

                    // 计算当前块长度与校验和并发送
                    string hexChunkLen = MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(currentChunkSize.ToString("X")));
                    string checksum = SumArray(chunk);

                    XSend(AddOn.HexStringToBytes("00000000", _context));
                    XSend(AddOn.HexStringToBytes(checksum, _context));

                    _port.WritePort(AddOn.HexStringToBytes("EFEEEEFE01000000" + hexChunkLen, _context));
                    _port.WritePort(chunk);

                    totalWritten += currentChunkSize;
                    _context?.UpdateProgress("WRITE_PARTITION_RAW_" + partName.ToUpper(), totalWritten, payload.Length, $"正在向 {partName} 写入原始字节...");
                }
                watch.Stop();
            }

            // 校验最终状态
            string finalStatus = AddOn.BytesToHexString(_serial.ReadUSB(16));
            if (finalStatus.Length >= 8 && !finalStatus.EndsWith("00000000"))
            {
                _context?.Log($"WriteByPartitionName 写入报告状态错误: 0x{finalStatus}", MtkLogLevel.Warning);
                return false;
            }

            _context?.Log($"目标分区 '{partName}' 配置成功。", MtkLogLevel.Success);
            return true;
        }

        /// <summary>
        /// 将指定文件镜像写入目标分区（文件路径重载版本）。
        /// </summary>
        public bool WriteByPartitionName(string partName, string filePath)
        {
            if (!File.Exists(filePath))
            {
                _context?.Log($"未在目标路径下找到分区负载镜像文件: {filePath}", MtkLogLevel.Error);
                return false;
            }

            // 下发写入初始化命令
            if (!_port.Send00000(16, "Write Part format", "09 00 01 00", "100")) return false;
            if (!_port.Send00000(16, "Write payload setup", "07 00 04 00", "100")) return false;

            _serial.ReadUSB(20);
            int pktLen = 1048576 * 2;
            _serial.ReadUSB(16);

            if (!_port.Send00000(16, "Write byname parameters", "01 00 01 00", "100")) return false;

            // 发送分区名称长度及名称
            string hexNameLen = MtkUtils.Penggenapan4Belakang(partName.Length.ToString("X"));
            _port.WritePort(AddOn.HexStringToBytes("EFEEEEFE01000000" + hexNameLen, _context));
            _port.WritePort(Encoding.UTF8.GetBytes(partName));

            // 发送文件总长度后开始非稀疏写入
            long fileLength = new FileInfo(filePath).Length;
            string hexPayloadLen = MtkUtils.Penggenapan8(MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(fileLength.ToString("X"))));
            XSend8(AddOn.HexStringToBytes(hexPayloadLen, _context));

            _serial.ReadUSB(16);
            return WriteUnsparse(filePath, pktLen);
        }

        /// <summary>
        /// 以非稀疏方式分块写入文件镜像，并实时上报速度与进度。
        /// </summary>
        public bool WriteUnsparse(string filePath, int pktLen)
        {
            FileInfo file = new FileInfo(filePath);
            long fileLength = file.Length;
            if (fileLength <= pktLen)
            {
                pktLen = (int)fileLength;
            }

            try
            {
                string status;
                using (FileStream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                {
                    long totalWritten = 0;
                    Stopwatch watch = Stopwatch.StartNew();

                    while (totalWritten < fileLength)
                    {
                        int currentChunkSize = (int)Math.Min(fileLength - totalWritten, pktLen);
                        byte[] chunk = new byte[currentChunkSize];
                        stream.Read(chunk, 0, currentChunkSize);

                        // 计算当前块长度与校验和并发送
                        string hexChunkLen = MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(currentChunkSize.ToString("X")));
                        string checksum = SumArray(chunk);

                        XSend(AddOn.HexStringToBytes("00000000", _context));
                        XSend(AddOn.HexStringToBytes(checksum, _context));

                        _port.WritePort(AddOn.HexStringToBytes("EFEEEEFE01000000" + hexChunkLen, _context));
                        _port.WritePort(chunk);

                        totalWritten += currentChunkSize;
                        double speed = (double)totalWritten / watch.Elapsed.TotalSeconds;

                        _context?.UpdateProgress(
                            "WRITE_UNSPARSE_IMAGE", 
                            totalWritten, 
                            fileLength, 
                            $"正在刷写 {file.Name}（{MtkUtils.GetFileSize((long)speed)}/秒）..."
                        );

                        // 校验每块写入后的状态
                        status = AddOn.BytesToHexString(_serial.ReadUSB(16));
                        if (status.Length >= 8 && !status.EndsWith("00000000"))
                        {
                            _context?.Log("写入失败，错误码: 0x" + status, MtkLogLevel.Error);
                            return false;
                        }
                    }
                    watch.Stop();
                }

                // 校验最终验证状态
                status = AddOn.BytesToHexString(_serial.ReadUSB(16));
                if (status.Length >= 8 && !status.EndsWith("00000000"))
                {
                    _context?.Log("最终验证检查返回错误状态: 0x" + status, MtkLogLevel.Error);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("WriteUnsparse 失败: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 以固定 8 字节长度前缀发送数据块。
        /// </summary>
        public void XSend8(byte[] data)
        {
            _port.WritePort(AddOn.HexStringToBytes("EFEEEEFE0100000008000000", _context));
            _port.WritePort(data);
        }

        /// <summary>
        /// MTK 字节块校验和辅助方法，计算原始字节累加和并映射为十六进制格式。
        /// </summary>
        public string SumArray(byte[] data)
        {
            // 累加所有字节
            int sum = 0;
            for (int i = 0; i < data.Length; i++)
            {
                sum += data[i];
            }

            // 取低 16 位（4 个十六进制字符）并转换字节序
            string sumHex = sum.ToString("X");
            if (sumHex.Length > 4)
            {
                return MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(sumHex.Substring(sumHex.Length - 4)));
            }
            return MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(sumHex));
        }

        /// <summary>
        /// 设置刷机环境并执行 SYNC 同步握手。
        /// </summary>
        public bool SetupEnv(string parameterDirectionHex)
        {
            XSend4(AddOn.HexStringToBytes("00010100", _context));
            _port.WritePort(AddOn.HexStringToBytes("EFEEEEFE0100000014000000", _context));
            _port.WritePort(AddOn.HexStringToBytes(parameterDirectionHex, _context));
            Thread.Sleep(100);

            _serial.ReadUSB(16);
            XSend4(AddOn.HexStringToBytes("01010100", _context));
            XSend(AddOn.HexStringToBytes("00000000", _context));
            
            // 检测响应中是否包含 SYNC（53594e43）标识
            byte[] status = _serial.ReadUSB(16);
            if (AddOn.BytesToHexString(status).ToLower().Contains("53594e43")) // SYNC
            {
                return true;
            }

            _context?.Log("SetupEnv 同步握手失败，状态寄存器: " + AddOn.BytesToHexString(status), MtkLogLevel.Warning);
            return false;
        }

        /// <summary>
        /// 从目标设备块读取完整分区数据并直接转储到目标文件目录。
        /// </summary>
        public bool BackupPartition(string partitionName, string targetFilePath)
        {
            try
            {
                contextLogWrap("开始转储目标分区: " + partitionName);
                _port.Send00000(16, "dump part init 1", "09 00 01 00", "100");
                _port.Send00000(16, "dump part init 2", "07 00 04 00", "100");

                // 读取并跳过若干描述符数据块
                byte[] bufferBytes = _serial.ReadUSB(8);
                bufferBytes = _serial.ReadUSB(4);

                string lenToRead = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(bufferBytes)));
                if (Convert.ToDouble(lenToRead) > 0)
                {
                    _serial.ReadUSB(Convert.ToInt32(lenToRead));
                }

                bufferBytes = _serial.ReadUSB(8);
                bufferBytes = _serial.ReadUSB(4);
                lenToRead = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(bufferBytes)));
                if (Convert.ToDouble(lenToRead) > 0)
                {
                    _serial.ReadUSB(Convert.ToInt32(lenToRead));
                }

                _port.Send00000(16, "dump part initialization 3", "02 00 01 00", "100");

                // 发送分区名称长度及名称
                string partitionNameLenHex = partitionName.Length.ToString("X");
                if (partitionNameLenHex.Length == 1) partitionNameLenHex = "0" + partitionNameLenHex;
                _port.WritePort(AddOn.HexStringToBytes("EFEEEEFE01000000" + partitionNameLenHex + "000000", _context));
                _port.WritePort(Encoding.UTF8.GetBytes(partitionName));

                bufferBytes = _serial.ReadUSB(8);
                bufferBytes = _serial.ReadUSB(4);
                lenToRead = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(bufferBytes)));
                if (Convert.ToDouble(lenToRead) > 0)
                {
                    _serial.ReadUSB(Convert.ToInt32(lenToRead));
                }

                bufferBytes = _serial.ReadUSB(8);
                bufferBytes = _serial.ReadUSB(4);
                lenToRead = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(bufferBytes)));
                if (Convert.ToDouble(lenToRead) > 0)
                {
                    _serial.ReadUSB(Convert.ToInt32(lenToRead));
                }

                // 解析分区总长度
                string lenPartitionBytes = MtkUtils.HexToDec(AddOn.ApplyShiftKiri2(AddOn.BytesToHexString(bufferBytes)));
                _serial.ReadUSB(16);

                byte[] sizeDescriptor = _serial.ReadUSB(12);
                string expectedChunkSize = MtkUtils.HexToDec(AddOn.BytesToHexString(sizeDescriptor.Skip(8).ToArray().Reverse().ToArray()));

                long totalBytesDumped = 0;
                long totalLength = Convert.ToInt64(lenPartitionBytes);

                if (File.Exists(targetFilePath)) File.Delete(targetFilePath);

                // 分块读取分区数据并写入文件
                using (FileStream stream = new FileStream(targetFilePath, FileMode.Append, FileAccess.Write))
                {
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    int dumpBufferSize = 2097152; // 默认 2MB 读取缓冲区
                    if (Convert.ToDouble(lenPartitionBytes) <= dumpBufferSize)
                    {
                        dumpBufferSize = Convert.ToInt32(lenPartitionBytes);
                    }

                    // 读取首个数据块
                    byte[] dumpedData = _serial.ReadUSB(dumpBufferSize);
                    totalBytesDumped += dumpedData.Length;
                    stream.Write(dumpedData, 0, dumpedData.Length);
                    _port.Send00000(16, "dump iteration step 1", "", "100");

                    // 循环读取剩余数据块
                    long expectedLeftBytes = Convert.ToInt64(lenPartitionBytes) - dumpedData.Length;
                    while (expectedLeftBytes > 0)
                    {
                        byte[] sizeBuff = _serial.ReadUSB(12);
                        expectedChunkSize = MtkUtils.HexToDec(AddOn.BytesToHexString(sizeBuff.Skip(8).ToArray().Reverse().ToArray()));

                        int sizeToReadNow = Convert.ToInt32(expectedChunkSize);
                        dumpedData = _serial.ReadUSB(sizeToReadNow);
                        totalBytesDumped += dumpedData.Length;
                        stream.Write(dumpedData, 0, dumpedData.Length);
                        expectedLeftBytes -= dumpedData.Length;

                        double speed = (double)totalBytesDumped / stopwatch.Elapsed.TotalSeconds;

                        _context?.UpdateProgress(
                            "DUMP_PARTITION_" + partitionName.ToUpper(),
                            totalBytesDumped,
                            totalLength,
                            $"正在转储 {partitionName}（{MtkUtils.GetFileSize((long)speed)}/秒）..."
                        );

                        _port.Send00000(16, "dump loop step", "", "100");
                    }
                    stopwatch.Stop();
                }

                _context?.Log($"分区转储序列已成功完成，镜像保存于: {targetFilePath}", MtkLogLevel.Success);
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("BackupPartition 核心流程失败: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 在指定范围内执行格式化（Format）命令。
        /// </summary>
        public bool FormatSector(string partitionType, string startSectorStr, string lenSectorStr)
        {
            try
            {
                // 下发格式化初始化命令
                if (!_port.Send00000(16, "Format Init 1", "09 00 01 00", "100")) return false;
                if (!_port.Send00000(16, "Format Init 2", "01 00 08 00", "100")) return false;
                if (!_port.Send00000(16, "Format Init 3", "03 00 01 00", "100")) return false;

                // 构造并发送格式化命令
                byte[] formatCommandBytes = CmdFormatBuild(partitionType, startSectorStr, lenSectorStr);
                _port.WritePort(AddOn.HexStringToBytes("EFEEEEFE0100000038000000", _context));
                _port.WritePort(formatCommandBytes);

                // 校验初始响应
                string response = AddOn.BytesToHexString(_serial.ReadUSB(16));
                if (response.Length != 32 || !response.EndsWith("00"))
                {
                    _context?.Log("格式化扇区请求在原生 BROM 命令层失败。", MtkLogLevel.Error);
                    return false;
                }

                _serial.ReadUSB(16);
                response = AddOn.BytesToHexString(_serial.ReadUSB(16));
                if (response.Length != 32)
                {
                    int paddingNeeded = 32 - response.Length;
                    response += AddOn.BytesToHexString(_serial.ReadUSB(paddingNeeded));
                }

                // 循环等待格式化完成的成功状态码
                while (true)
                {
                    XSend4(AddOn.HexStringToBytes("00000000", _context));
                    response = AddOn.BytesToHexString(_serial.ReadUSB(16));

                    if (response.Length != 32) return false;
                    response = AddOn.BytesToHexString(_serial.ReadUSB(16));

                    if (response.Length != 32) return false;

                    if (response.ToLower().Contains("5000440")) // 等效于成功执行代码
                    {
                        break;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("FormatSector 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 构建格式化命令字节数组，根据存储类型与分区类型设置相应标志位。
        /// </summary>
        private byte[] CmdFormatBuild(string partitionType, string startSectorStr, string lenSectorStr)
        {
            string flag1 = "01000000"; // 默认 eMMC 格式化值标志
            string flag2 = "08000000"; // 默认 eMMC 用户区标志

            if (StorageType.ToLower() == "ufs")
            {
                flag1 = "30000000";
                flag2 = (partitionType.ToLower() == "boot1") ? "01000000" : "03000000";
            }
            else
            {
                flag2 = (partitionType.ToLower() == "boot1") ? "01000000" : "08000000";
            }

            // 补齐起始扇区与长度，并附加保留字段
            string padding8Start = MtkUtils.Penggenapan8(AddOn.ApplyShiftKiri2(startSectorStr));
            string padding8Len = MtkUtils.Penggenapan8(AddOn.ApplyShiftKiri2(lenSectorStr));
            string emptyReservations = "0000000000000000000000000000000000000000000000000000000000000000";

            return AddOn.HexStringToBytes(flag1 + flag2 + padding8Start + padding8Len + emptyReservations, _context);
        }

        /// <summary>
        /// 上下文日志包装辅助方法，以信息级别记录日志。
        /// </summary>
        private void contextLogWrap(string info)
        {
            _context?.Log(info, MtkLogLevel.Info);
        }

        #region RPMB 专用操作

        /// <summary>
        /// 读取 RPMB（Replay Protected Memory Block）数据。
        /// RPMB 是 eMMC 的特殊安全区域，需要专门的读取命令。
        /// </summary>
        /// <param name="address">RPMB 块地址（从 0 开始）</param>
        /// <param name="blockCount">要读取的块数量（每块 256 字节）</param>
        /// <param name="savePath">保存路径（可选，留空则返回数据）</param>
        /// <returns>读取的 RPMB 数据（如果未指定保存路径）</returns>
        public byte[] ReadRpmb(int address, int blockCount, string savePath = "")
        {
            try
            {
                _context?.Log($"正在读取 RPMB: 地址={address}, 块数={blockCount}", MtkLogLevel.Info);

                // 步骤 1: 发送 RPMB 读取初始化命令
                if (!_port.Send00000(16, "RPMB 读取命令 1", "09 00 01 00", "100"))
                {
                    _context?.Log("RPMB 读取初始化失败", MtkLogLevel.Error);
                    return Array.Empty<byte>();
                }

                // 步骤 2: 发送 RPMB 读取准备命令
                if (!_port.Send00000(16, "RPMB 读取命令 2", "0D 00 0C 00", "100"))
                {
                    _context?.Log("RPMB 读取准备命令失败", MtkLogLevel.Error);
                    return Array.Empty<byte>();
                }

                // 步骤 3: 构建 RPMB 读取参数
                // 格式: [地址(4字节)] [块数(4字节)] [保留(4字节)]
                string addrHex = MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(address.ToString("X")));
                string countHex = MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(blockCount.ToString("X")));
                string reserved = "00000000";

                byte[] readParams = AddOn.HexStringToBytes(addrHex + countHex + reserved, _context);
                
                // 步骤 4: 发送读取参数
                _port.WritePort(AddOn.HexStringToBytes("EF EE EE FE 01 00 00 00 0C 00 00 00", _context));
                _port.WritePort(readParams);

                // 步骤 5: 读取响应状态
                byte[] response = _serial.ReadUSB(16);
                string responseHex = AddOn.BytesToHexString(response);

                if (!responseHex.ToUpper().Contains("00"))
                {
                    _context?.Log($"RPMB 读取请求失败: {responseHex}", MtkLogLevel.Error);
                    return Array.Empty<byte>();
                }

                // 步骤 6: 读取 RPMB 数据
                // 每个 RPMB 块是 256 字节
                int totalBytes = blockCount * 256;
                byte[] rpmbData = new byte[totalBytes];
                
                _serial.ReadUSB(12); // 跳过头部
                
                int bytesRead = 0;
                while (bytesRead < totalBytes)
                {
                    int chunkSize = Math.Min(4096, totalBytes - bytesRead);
                    byte[] chunk = _serial.ReadUSB(chunkSize);
                    Buffer.BlockCopy(chunk, 0, rpmbData, bytesRead, chunk.Length);
                    bytesRead += chunk.Length;
                    
                    _context?.UpdateProgress("读取 RPMB", bytesRead, totalBytes);
                }

                _context?.Log($"✓ RPMB 读取成功: {bytesRead} 字节", MtkLogLevel.Success);

                // 步骤 7: 如果指定了保存路径，则保存到文件
                if (!string.IsNullOrEmpty(savePath))
                {
                    File.WriteAllBytes(savePath, rpmbData);
                    _context?.Log($"RPMB 数据已保存至: {savePath}", MtkLogLevel.Info);
                }

                return rpmbData;
            }
            catch (Exception ex)
            {
                _context?.Log("ReadRpmb 异常: " + ex.Message, MtkLogLevel.Error);
                return Array.Empty<byte>();
            }
        }

        /// <summary>
        /// 写入 RPMB（Replay Protected Memory Block）数据。
        /// RPMB 写入需要认证密钥，通常用于安全启动等场景。
        /// </summary>
        /// <param name="address">RPMB 块地址（从 0 开始）</param>
        /// <param name="data">要写入的数据（必须是 256 字节的倍数）</param>
        /// <param name="authKey">RPMB 认证密钥（32 字节，可选）</param>
        /// <returns>是否成功写入</returns>
        public bool WriteRpmb(int address, byte[] data, byte[] authKey = null)
        {
            try
            {
                if (data == null || data.Length == 0)
                {
                    _context?.Log("RPMB 数据为空", MtkLogLevel.Error);
                    return false;
                }

                // RPMB 数据必须是 256 字节的倍数
                if (data.Length % 256 != 0)
                {
                    _context?.Log($"RPMB 数据长度必须是 256 字节的倍数，当前长度: {data.Length}", MtkLogLevel.Error);
                    return false;
                }

                int blockCount = data.Length / 256;
                _context?.Log($"正在写入 RPMB: 地址={address}, 块数={blockCount}", MtkLogLevel.Info);

                // 步骤 1: 发送 RPMB 写入初始化命令
                if (!_port.Send00000(16, "RPMB 写入命令 1", "09 00 01 00", "100"))
                {
                    _context?.Log("RPMB 写入初始化失败", MtkLogLevel.Error);
                    return false;
                }

                // 步骤 2: 发送 RPMB 写入准备命令
                if (!_port.Send00000(16, "RPMB 写入命令 2", "0E 00 0C 00", "100"))
                {
                    _context?.Log("RPMB 写入准备命令失败", MtkLogLevel.Error);
                    return false;
                }

                // 步骤 3: 构建 RPMB 写入参数
                string addrHex = MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(address.ToString("X")));
                string countHex = MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(blockCount.ToString("X")));
                string reserved = "00000000";

                byte[] writeParams = AddOn.HexStringToBytes(addrHex + countHex + reserved, _context);
                
                // 步骤 4: 发送写入参数
                _port.WritePort(AddOn.HexStringToBytes("EF EE EE FE 01 00 00 00 0C 00 00 00", _context));
                _port.WritePort(writeParams);

                // 步骤 5: 读取参数确认
                byte[] response = _serial.ReadUSB(16);
                string responseHex = AddOn.BytesToHexString(response);

                if (!responseHex.ToUpper().Contains("00"))
                {
                    _context?.Log($"RPMB 写入参数确认失败: {responseHex}", MtkLogLevel.Error);
                    return false;
                }

                // 步骤 6: 发送 RPMB 数据
                int dataLenHex = data.Length;
                string lenHeader = MtkUtils.Penggenapan4Belakang(AddOn.ApplyShiftKiri2(dataLenHex.ToString("X")));
                
                _port.WritePort(AddOn.HexStringToBytes("EF EE EE FE 01 00 00 00 " + lenHeader, _context));
                
                // 分块发送数据
                int sent = 0;
                while (sent < data.Length)
                {
                    int chunkSize = Math.Min(4096, data.Length - sent);
                    byte[] chunk = new byte[chunkSize];
                    Buffer.BlockCopy(data, sent, chunk, 0, chunkSize);
                    _port.WritePort(chunk);
                    sent += chunkSize;
                    
                    _context?.UpdateProgress("写入 RPMB", sent, data.Length);
                }

                // 步骤 7: 读取写入确认
                response = _serial.ReadUSB(16);
                responseHex = AddOn.BytesToHexString(response);

                if (responseHex.ToUpper().Contains("00"))
                {
                    _context?.Log($"✓ RPMB 写入成功: {data.Length} 字节", MtkLogLevel.Success);
                    return true;
                }
                else
                {
                    _context?.Log($"RPMB 写入失败: {responseHex}", MtkLogLevel.Error);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _context?.Log("WriteRpmb 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 从文件写入 RPMB 数据。
        /// </summary>
        /// <param name="address">RPMB 块地址</param>
        /// <param name="filePath">要写入的文件路径</param>
        /// <param name="authKey">RPMB 认证密钥（可选）</param>
        /// <returns>是否成功写入</returns>
        public bool WriteRpmbFromFile(int address, string filePath, byte[] authKey = null)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    _context?.Log($"RPMB 源文件不存在: {filePath}", MtkLogLevel.Error);
                    return false;
                }

                byte[] data = File.ReadAllBytes(filePath);
                _context?.Log($"已加载 RPMB 数据: {filePath} ({data.Length} 字节)", MtkLogLevel.Info);

                return WriteRpmb(address, data, authKey);
            }
            catch (Exception ex)
            {
                _context?.Log("WriteRpmbFromFile 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 擦除 RPMB（Replay Protected Memory Block）数据。
        /// 实际上是将指定区域写入全 0xFF 或 0x00。
        /// </summary>
        /// <param name="address">RPMB 块地址（从 0 开始）</param>
        /// <param name="blockCount">要擦除的块数量</param>
        /// <param name="fillByte">填充字节（默认 0xFF）</param>
        /// <returns>是否成功擦除</returns>
        public bool EraseRpmb(int address, int blockCount, byte fillByte = 0xFF)
        {
            try
            {
                _context?.Log($"正在擦除 RPMB: 地址={address}, 块数={blockCount}, 填充值=0x{fillByte:X2}", MtkLogLevel.Info);

                // 创建填充数据（256 字节 × 块数）
                int totalBytes = blockCount * 256;
                byte[] eraseData = new byte[totalBytes];
                
                for (int i = 0; i < totalBytes; i++)
                {
                    eraseData[i] = fillByte;
                }

                // 使用写入功能执行擦除
                if (WriteRpmb(address, eraseData))
                {
                    _context?.Log($"✓ RPMB 擦除成功: {blockCount} 块", MtkLogLevel.Success);
                    return true;
                }
                else
                {
                    _context?.Log("RPMB 擦除失败", MtkLogLevel.Error);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _context?.Log("EraseRpmb 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 获取 RPMB 容量信息。
        /// </summary>
        /// <returns>RPMB 大小（块数）</returns>
        public int GetRpmbSize()
        {
            try
            {
                if (RpmbSizeBlocks > 0)
                {
                    return RpmbSizeBlocks;
                }

                // 从 EmmcRpmb 字符串解析 RPMB 大小
                if (!string.IsNullOrEmpty(EmmcRpmb))
                {
                    long rpmbBytes = Convert.ToInt64(MtkUtils.HexToDec(EmmcRpmb));
                    RpmbSizeBlocks = (int)(rpmbBytes / 256); // 每块 256 字节
                    
                    _context?.Log($"RPMB 容量: {RpmbSizeBlocks} 块 ({rpmbBytes} 字节)", MtkLogLevel.Info);
                    return RpmbSizeBlocks;
                }

                _context?.Log("RPMB 容量未知，请先调用 GetEmmcInfoBrom()", MtkLogLevel.Warning);
                return 0;
            }
            catch (Exception ex)
            {
                _context?.Log("GetRpmbSize 异常: " + ex.Message, MtkLogLevel.Error);
                return 0;
            }
        }

        /// <summary>
        /// 备份整个 RPMB 区域到文件。
        /// </summary>
        /// <param name="savePath">保存路径</param>
        /// <returns>是否成功备份</returns>
        public bool BackupFullRpmb(string savePath)
        {
            try
            {
                int rpmbBlocks = GetRpmbSize();
                
                if (rpmbBlocks == 0)
                {
                    _context?.Log("无法获取 RPMB 容量", MtkLogLevel.Error);
                    return false;
                }

                _context?.Log($"正在备份完整 RPMB 区域: {rpmbBlocks} 块", MtkLogLevel.Info);

                byte[] rpmbData = ReadRpmb(0, rpmbBlocks);
                
                if (rpmbData.Length > 0)
                {
                    File.WriteAllBytes(savePath, rpmbData);
                    _context?.Log($"✓ RPMB 完整备份已保存: {savePath} ({rpmbData.Length} 字节)", MtkLogLevel.Success);
                    return true;
                }
                else
                {
                    _context?.Log("RPMB 备份失败", MtkLogLevel.Error);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _context?.Log("BackupFullRpmb 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 恢复 RPMB 区域从备份文件。
        /// </summary>
        /// <param name="backupPath">备份文件路径</param>
        /// <returns>是否成功恢复</returns>
        public bool RestoreFullRpmb(string backupPath)
        {
            try
            {
                if (!File.Exists(backupPath))
                {
                    _context?.Log($"RPMB 备份文件不存在: {backupPath}", MtkLogLevel.Error);
                    return false;
                }

                byte[] rpmbData = File.ReadAllBytes(backupPath);
                
                // 验证数据长度是 256 的倍数
                if (rpmbData.Length % 256 != 0)
                {
                    _context?.Log($"RPMB 备份文件大小无效: {rpmbData.Length} 字节（必须是 256 的倍数）", MtkLogLevel.Error);
                    return false;
                }

                int blockCount = rpmbData.Length / 256;
                _context?.Log($"正在恢复 RPMB: {blockCount} 块", MtkLogLevel.Info);

                if (WriteRpmb(0, rpmbData))
                {
                    _context?.Log($"✓ RPMB 恢复成功: {rpmbData.Length} 字节", MtkLogLevel.Success);
                    return true;
                }
                else
                {
                    _context?.Log("RPMB 恢复失败", MtkLogLevel.Error);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _context?.Log("RestoreFullRpmb 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        #endregion
    }
}
