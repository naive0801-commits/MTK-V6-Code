using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using Microsoft.Win32.SafeHandles;
using MtkFlashLib.Serial.Win32;

namespace MtkFlashLib.Serial
{
    /// <summary>
    /// 串口通信库，通过 Win32 原生 API 管理串口句柄并执行读写操作。
    /// </summary>
    public class SerialLib : IDisposable
    {
        private SafeFileHandle _portFd = new SafeFileHandle(IntPtr.Zero, false);
        private MtkContext _context;

        /// <summary>是否已连接</summary>
        public bool IsConnected { get; private set; } = false;

        /// <summary>
        /// 构造函数，注入 MtkContext 上下文依赖。
        /// </summary>
        public SerialLib(MtkContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 尝试打开串行通道，连接到目标设备。
        /// </summary>
        public bool Open(string devicePath)
        {
            DCB dcbParams = default(DCB);
            COMMTIMEOUTS timeouts = default(COMMTIMEOUTS);

            // 创建串口文件句柄
            _portFd = Win32Native.CreateFile(
                devicePath,
                MtkFlashLib.Serial.Win32.FileAccess.GenericRead | MtkFlashLib.Serial.Win32.FileAccess.GenericWrite,
                MtkFlashLib.Serial.Win32.FileShareMode.Read | MtkFlashLib.Serial.Win32.FileShareMode.Write,
                IntPtr.Zero,
                MtkFlashLib.Serial.Win32.FilePosition.OpenExisting,
                MtkFlashLib.Serial.Win32.FileAttributes.Normal,
                IntPtr.Zero);

            if (_portFd.IsInvalid)
            {
                _context?.Log("无法在串口上打开读/写句柄: " + devicePath, MtkLogLevel.Error);
                IsConnected = false;
                return false;
            }

            // 配置 DCB 参数：波特率、数据位、停止位、校验位
            dcbParams.BaudRate = 115200;
            dcbParams.ByteSize = 8;
            dcbParams.StopBits = 1;
            dcbParams.Parity = 0;

            if (!Win32Native.SetCommState(_portFd, ref dcbParams))
            {
                _context?.Log("无法在原生设备端口句柄上写入状态描述符。", MtkLogLevel.Warning);
                _portFd.Close();
                IsConnected = false;
                return false;
            }

            // 配置通信超时
            timeouts.ReadTotalTimeoutMultiplier = 1000;
            timeouts.WriteTotalTimeoutMultiplier = 1000;
            timeouts.ReadIntervalTimeout = 50;
            timeouts.ReadTotalTimeoutConstant = 50;
            timeouts.WriteTotalTimeoutConstant = 50;

            if (!Win32Native.SetCommTimeouts(_portFd, ref timeouts))
            {
                _context?.Log("设置原生端口 COM 超时失败。", MtkLogLevel.Warning);
            }

            IsConnected = true;
            return true;
        }

        /// <summary>
        /// 通过活动串行流下发原始二进制数据包。
        /// </summary>
        public bool WriteUSB(byte[] buffer)
        {
            if (!IsConnected) return false;

            int tempSend = 0;
            try
            {
                if (!Win32Native.WriteFile(_portFd, buffer, buffer.Length, ref tempSend, IntPtr.Zero))
                {
                    _context?.Log("WriteUSB 原生错误: 写入失败。", MtkLogLevel.Error);
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("WriteUSB 发生异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 读取精确长度的响应数据，适用于固定字节响应。
        /// </summary>
        public byte[] ReadUSB(int expectedLength)
        {
            if (!IsConnected) return Array.Empty<byte>();

            byte[] buffer = new byte[expectedLength];
            int totalBytesRead = 0;

            try
            {
                int bytesRead = 0;
                if (!Win32Native.ReadFile(_portFd, buffer, expectedLength, ref bytesRead, IntPtr.Zero))
                {
                    _context?.Log("ReadUSB 原生错误: 读取失败。", MtkLogLevel.Error);
                    return Array.Empty<byte>();
                }
                totalBytesRead += bytesRead;
            }
            catch (Exception ex)
            {
                _context?.Log("ReadUSB 发生异常: " + ex.Message, MtkLogLevel.Error);
                return Array.Empty<byte>();
            }

            // 若实际读取少于期望长度，调整缓冲区大小
            if (totalBytesRead < expectedLength)
            {
                Array.Resize(ref buffer, totalBytesRead);
            }
            return buffer;
        }

        /// <summary>
        /// 拉取 COM 队列中当前缓冲的所有可用内容。
        /// </summary>
        public byte[] USBRead()
        {
            if (!IsConnected) return Array.Empty<byte>();

            int maxRead = 2097152; // 默认 MTK 快速传输缓冲区
            byte[] buffer = new byte[maxRead];
            int bytesRead = 0;

            try
            {
                if (!Win32Native.ReadFile(_portFd, buffer, maxRead, ref bytesRead, IntPtr.Zero))
                {
                    _context?.Log("USBRead 原生错误: 批量读取操作失败。", MtkLogLevel.Error);
                    return Array.Empty<byte>();
                }
            }
            catch (Exception ex)
            {
                _context?.Log("USBRead 发生异常: " + ex.Message, MtkLogLevel.Error);
                return Array.Empty<byte>();
            }

            byte[] result = new byte[bytesRead];
            Buffer.BlockCopy(buffer, 0, result, 0, bytesRead);
            return result;
        }

        /// <summary>
        /// 丢弃输入缓冲区中的数据。
        /// </summary>
        public bool DiscardInBuffer()
        {
            if (!IsConnected) return false;
            return Win32Native.PurgeComm(_portFd, 10u);
        }

        /// <summary>
        /// 丢弃输出缓冲区中的数据。
        /// </summary>
        public bool DiscardOutBuffer()
        {
            if (!IsConnected) return false;
            return Win32Native.PurgeComm(_portFd, 5u);
        }

        /// <summary>
        /// 关闭串口连接。
        /// </summary>
        public void Close()
        {
            if (IsConnected)
            {
                IsConnected = false;
                Win32Native.FlushFileBuffers(_portFd);
                _portFd.Close();
            }
        }

        /// <summary>
        /// 释放资源。
        /// </summary>
        public void Dispose()
        {
            Close();
        }
    }
}
