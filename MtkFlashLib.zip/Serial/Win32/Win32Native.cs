using System;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32.SafeHandles;

namespace MtkFlashLib.Serial.Win32
{
    /// <summary>
    /// 文件访问权限标志。
    /// </summary>
    [Flags]
    public enum FileAccess : uint
    {
        /// <summary>读取权限</summary>
        GenericRead = 0x80000000,
        /// <summary>写入权限</summary>
        GenericWrite = 0x40000000
    }

    /// <summary>
    /// 文件共享模式标志。
    /// </summary>
    [Flags]
    public enum FileShareMode : uint
    {
        /// <summary>无共享</summary>
        None = 0x00000000,
        /// <summary>允许读取共享</summary>
        Read = 0x00000001,
        /// <summary>允许写入共享</summary>
        Write = 0x00000002
    }

    /// <summary>
    /// 文件打开/创建位置模式。
    /// </summary>
    public enum FilePosition : uint
    {
        /// <summary>创建新文件，若已存在则失败</summary>
        CreateNew = 1,
        /// <summary>始终创建文件，若已存在则覆盖</summary>
        CreateAlways = 2,
        /// <summary>打开已存在文件，若不存在则失败</summary>
        OpenExisting = 3,
        /// <summary>打开已存在文件，若不存在则创建</summary>
        OpenAlways = 4,
        /// <summary>打开并截断已存在文件</summary>
        TruncateExisting = 5
    }

    /// <summary>
    /// 文件属性标志。
    /// </summary>
    [Flags]
    public enum FileAttributes : uint
    {
        /// <summary>普通文件</summary>
        Normal = 0x00000080
    }

    /// <summary>
    /// COM 端口属性结构。
    /// </summary>
    public struct COMMPROP
    {
        public ushort wPacketLength;
        public ushort wPacketVersion;
        public int dwServiceMask;
        public int dwReserved1;
        public int dwMaxTxQueue;
        public int dwMaxRxQueue;
        public int dwMaxBaud;
        public int dwProvSubType;
        public int dwProvCapabilities;
        public int dwSettableParams;
        public int dwSettableBaud;
        public ushort wSettableData;
        public ushort wSettableStopParity;
        public int dwCurrentTxQueue;
        public int dwCurrentRxQueue;
        public int dwProvSpec1;
        public int dwProvSpec2;
        public char wcProvChar;
    }

    /// <summary>
    /// COM 通信超时设置结构。
    /// </summary>
    public struct COMMTIMEOUTS
    {
        public int ReadIntervalTimeout;
        public int ReadTotalTimeoutMultiplier;
        public int ReadTotalTimeoutConstant;
        public int WriteTotalTimeoutMultiplier;
        public int WriteTotalTimeoutConstant;
    }

    /// <summary>
    /// COM 端口状态结构。
    /// </summary>
    public struct COMSTAT
    {
        public uint Flags;
        public uint cbInQue;
        public uint cbOutQue;
    }

    /// <summary>
    /// 设备控制块（DCB），包含串口配置参数。
    /// </summary>
    public struct DCB
    {
        public uint DCBlength;
        public uint BaudRate;
        public uint Flags;
        public ushort wReserved;
        public ushort XonLim;
        public ushort XoffLim;
        public byte ByteSize;
        public byte Parity;
        public byte StopBits;
        public byte XonChar;
        public byte XoffChar;
        public byte ErrorChar;
        public byte EofChar;
        public byte EvtChar;
        public ushort wReserved1;
    }

    /// <summary>
    /// COM 端口信息结构，包含端口句柄与配置参数。
    /// </summary>
    public struct ComPort
    {
        /// <summary>端口文件句柄</summary>
        public SafeFileHandle port_fd;
        /// <summary>端口名称</summary>
        public string port_name;

        /// <summary>波特率（默认 115200）</summary>
        public static int BaudRate = 115200;
        /// <summary>超时（毫秒，默认 1000）</summary>
        public static int Timeout = 1000;
        /// <summary>读取超时（毫秒，默认 100）</summary>
        public static int readTimeout = 100;
        /// <summary>写入超时（毫秒，默认 100）</summary>
        public static int writeTimeout = 100;
        /// <summary>最大写入字节数（默认 2MB）</summary>
        public static int max_to_write = 2097152;
        /// <summary>最大读取字节数（默认 2MB）</summary>
        public static int max_to_read = 2097152;
    }

    /// <summary>
    /// Win32 原生 API 封装类，提供对 kernel32.dll 的串口操作函数调用。
    /// </summary>
    public class Win32Native
    {
        /// <summary>
        /// 创建或打开文件、管道、设备或串口等。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern SafeFileHandle CreateFile(
            string lpFileName,
            FileAccess dwDesiredAccess,
            FileShareMode dwShareMode,
            IntPtr lpSecurityAttributes,
            FilePosition dwCreationDisposition,
            FileAttributes dwFlagsAndAttributes,
            IntPtr hTemplateFile);

        /// <summary>
        /// 设置 COM 端口的通信超时参数。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool SetCommTimeouts(SafeFileHandle hCommDev, ref COMMTIMEOUTS lpCommTimeouts);

        /// <summary>
        /// 获取 COM 端口的通信超时参数。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool GetCommTimeouts(SafeFileHandle hCommDev, ref COMMTIMEOUTS lpCommTimeouts);

        /// <summary>
        /// 向文件或设备写入数据（重叠 I/O 版本）。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool WriteFile(
            SafeFileHandle hFile,
            byte[] lpBuffer,
            int nNumberOfBytesToWrite,
            ref int lpNumberOfBytesWritten,
            ref NativeOverlapped lpOverlapped);

        /// <summary>
        /// 向文件或设备写入数据（同步版本）。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool WriteFile(
            SafeFileHandle hFile,
            byte[] lpBuffer,
            int nNumberOfBytesToWrite,
            ref int lpNumberOfBytesWritten,
            IntPtr lpOverlapped);

        /// <summary>
        /// 从文件或设备读取数据（重叠 I/O 版本）。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool ReadFile(
            SafeFileHandle hFile,
            [Out] byte[] lpBuffer,
            int nNumberOfBytesToRead,
            ref int lpNumberOfBytesRead,
            ref NativeOverlapped lpOverlapped);

        /// <summary>
        /// 从文件或设备读取数据（同步版本）。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool ReadFile(
            SafeFileHandle hFile,
            [Out] byte[] lpBuffer,
            int nNumberOfBytesToRead,
            ref int lpNumberOfBytesRead,
            IntPtr lpOverlapped);

        /// <summary>
        /// 关闭已打开的对象句柄。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool CloseHandle(SafeFileHandle hCommDev);

        /// <summary>
        /// 获取重叠 I/O 操作的结果。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool GetOverlappedResult(
            SafeFileHandle hFile,
            ref NativeOverlapped lpOverlapped,
            ref int nNumberOfBytesTransferred,
            bool bWait);

        /// <summary>
        /// 清除 COM 端口错误并获取状态。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool ClearCommError(SafeFileHandle hFile, ref int lpErrors, ref COMSTAT lpStat);

        /// <summary>
        /// 设置 COM 端口的输入输出缓冲区大小。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool SetupComm(SafeFileHandle hFile, int dwInQueue, int dwOutQueue);

        /// <summary>
        /// 获取 COM 端口的属性。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool GetCommProperties(SafeFileHandle hFile, ref COMMPROP lpCommProp);

        /// <summary>
        /// 获取 COM 端口的调制解调器状态。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool GetCommModemStatus(SafeFileHandle hFile, ref int lpModemStat);

        /// <summary>
        /// 获取文件类型。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern int GetFileType(SafeFileHandle hFile);

        /// <summary>
        /// 清除 COM 端口缓冲区。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool PurgeComm(SafeFileHandle hFile, uint dwFlags);

        /// <summary>
        /// 获取 COM 端口的设备控制块（DCB）状态。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool GetCommState(SafeFileHandle hFile, ref DCB lpDCB);

        /// <summary>
        /// 设置 COM 端口的设备控制块（DCB）状态。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool SetCommState(SafeFileHandle hFile, ref DCB lpDCB);

        /// <summary>
        /// 刷新文件缓冲区，将缓冲数据写入磁盘。
        /// </summary>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern long FlushFileBuffers(SafeFileHandle hObject);
    }
}
