using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using MtkFlashLib.Serial.Win32;

namespace MtkFlashLib.Serial
{
    /// <summary>
    /// 基于 Win32 原生 API 的串行设备封装，提供 COM 端口的打开、读写、缓冲区清理等底层操作。
    /// </summary>
    public class SerialDevice : IDisposable
    {
        /// <summary>无效端口句柄值</summary>
        public const int InvalidPortHandleValue = -1;

        /// <summary>端口名称</summary>
        public string PortName { get; set; }
        /// <summary>波特率（默认 115200）</summary>
        public uint BaudRate { get; set; } = 115200;
        /// <summary>读取超时（毫秒）</summary>
        public int ReadTimeout { get; set; } = 1000;
        /// <summary>写入超时（毫秒）</summary>
        public int WriteTimeout { get; set; } = 1000;
        /// <summary>超时常量</summary>
        public int TimeoutConstant { get; set; } = 100;
        /// <summary>最大读取字节数</summary>
        public int MaxToRead { get; set; } = 2097152;
        /// <summary>最大写入字节数</summary>
        public int MaxToWrite { get; set; } = 2097152;

        /// <summary>是否已连接</summary>
        public bool IsConnected { get; private set; } = false;
        /// <summary>COM 端口对象</summary>
        public ComPort ComPort { get; private set; }

        private COMSTAT _comStat;

        /// <summary>
        /// 获取输入队列中待读取的字节数。
        /// </summary>
        public int BytesToRead
        {
            get
            {
                int errors = 0;
                if (!Win32Native.ClearCommError(ComPort.port_fd, ref errors, ref _comStat))
                {
                    return -1;
                }
                return (int)_comStat.cbInQue;
            }
        }

        /// <summary>
        /// 构造函数，指定要操作的端口名称。
        /// </summary>
        public SerialDevice(string portName)
        {
            PortName = portName;
        }

        /// <summary>
        /// 在目标 COM 端口上实例化原生句柄连接。
        /// </summary>
        public bool Open(MtkContext context = null)
        {
            ComPort port = new ComPort { port_name = PortName };
            DCB dcbParams = default(DCB);
            COMMTIMEOUTS timeouts = default(COMMTIMEOUTS);

            context?.Log("正在打开串行通道句柄: " + PortName, MtkLogLevel.Debug);

            // 创建串口文件句柄
            port.port_fd = Win32Native.CreateFile(
                port.port_name,
                MtkFlashLib.Serial.Win32.FileAccess.GenericRead | MtkFlashLib.Serial.Win32.FileAccess.GenericWrite,
                MtkFlashLib.Serial.Win32.FileShareMode.Read | MtkFlashLib.Serial.Win32.FileShareMode.Write,
                IntPtr.Zero,
                MtkFlashLib.Serial.Win32.FilePosition.OpenExisting,
                MtkFlashLib.Serial.Win32.FileAttributes.Normal, // 已修复的歧义引用！
                IntPtr.Zero);

            if (port.port_fd.IsInvalid)
            {
                context?.Log("无法在 " + PortName + " 上打开串行通道句柄", MtkLogLevel.Error);
                IsConnected = false;
                return false;
            }

            // 获取当前 COM 状态参数
            if (!Win32Native.GetCommState(port.port_fd, ref dcbParams))
            {
                context?.Log("无法获取端口 " + PortName + " 的 COM 状态参数", MtkLogLevel.Error);
                port.port_fd.Close();
                IsConnected = false;
                return false;
            }

            // 配置 DCB 参数
            dcbParams.BaudRate = BaudRate;
            dcbParams.ByteSize = 8;
            dcbParams.StopBits = 1; // 1 个停止位
            dcbParams.Parity = 0;   // 无校验位

            if (!Win32Native.SetCommState(port.port_fd, ref dcbParams))
            {
                context?.Log("无法将更新后的 DCB 配置写入端口 " + PortName, MtkLogLevel.Error);
                port.port_fd.Close();
                IsConnected = false;
                return false;
            }

            // 配置通信超时参数
            Win32Native.GetCommTimeouts(port.port_fd, ref timeouts);
            timeouts.ReadIntervalTimeout = TimeoutConstant;
            timeouts.ReadTotalTimeoutMultiplier = TimeoutConstant;
            timeouts.ReadTotalTimeoutConstant = ReadTimeout;
            timeouts.WriteTotalTimeoutMultiplier = TimeoutConstant;
            timeouts.WriteTotalTimeoutConstant = WriteTimeout;

            if (!Win32Native.SetCommTimeouts(port.port_fd, ref timeouts))
            {
                context?.Log("配置 COM 端口通信超时失败", MtkLogLevel.Warning);
            }

            // 分配读写缓冲区边界
            if (!Win32Native.SetupComm(port.port_fd, MaxToRead, MaxToWrite))
            {
                context?.Log("分配 COM 读/写缓冲区边界失败", MtkLogLevel.Warning);
            }

            ComPort = port;
            IsConnected = true;
            context?.Log("串行通道已在 " + PortName + " 上成功建立", MtkLogLevel.Info);
            return true;
        }

        /// <summary>
        /// 将完整的缓冲区数组分块写入端口。
        /// </summary>
        public bool Write(byte[] buffer, MtkContext context = null)
        {
            if (!IsConnected) return false;

            int bytesSent = 0;
            int bytesToSend = buffer.Length;
            ManualResetEvent resetEvent = new ManualResetEvent(false);
            NativeOverlapped lpOverlapped = new NativeOverlapped
            {
                OffsetLow = 0,
                OffsetHigh = 0,
                EventHandle = resetEvent.SafeWaitHandle.DangerousGetHandle()
            };

            // 循环分块发送，直到全部数据写完
            while (bytesSent < bytesToSend)
            {
                try
                {
                    int tempSend = 0;
                    int chunkSize = Math.Min(bytesToSend - bytesSent, ComPort.max_to_write);
                    byte[] chunk = new byte[chunkSize];
                    Buffer.BlockCopy(buffer, bytesSent, chunk, 0, chunkSize);

                    if (Win32Native.WriteFile(ComPort.port_fd, chunk, chunkSize, ref tempSend, ref lpOverlapped))
                    {
                        // 等待重叠 I/O 操作完成
                        if (Win32Native.GetOverlappedResult(ComPort.port_fd, ref lpOverlapped, ref tempSend, true))
                        {
                            bytesSent += tempSend;
                            continue;
                        }
                        return false;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    context?.Log("端口 " + PortName + " 写入错误: " + ex.Message, MtkLogLevel.Error);
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// 读取任何等待中的字节，最多不超过最大数据包限制。
        /// </summary>
        public byte[] Read(MtkContext context = null)
        {
            if (!IsConnected) return Array.Empty<byte>();

            int maxRead = MaxToRead;
            byte[] buffer = new byte[maxRead];
            int bytesRead = 0;
            ManualResetEvent resetEvent = new ManualResetEvent(false);
            NativeOverlapped lpOverlapped = new NativeOverlapped
            {
                OffsetLow = 0,
                OffsetHigh = 0,
                EventHandle = resetEvent.SafeWaitHandle.DangerousGetHandle()
            };

            try
            {
                int tempRead = 0;
                if (Win32Native.ReadFile(ComPort.port_fd, buffer, maxRead, ref tempRead, ref lpOverlapped))
                {
                    // 等待重叠 I/O 读取操作完成
                    if (Win32Native.GetOverlappedResult(ComPort.port_fd, ref lpOverlapped, ref tempRead, true))
                    {
                        bytesRead = tempRead;
                    }
                }
            }
            catch (Exception ex)
            {
                context?.Log("端口 " + PortName + " 读取错误: " + ex.Message, MtkLogLevel.Error);
                return Array.Empty<byte>();
            }

            byte[] result = new byte[bytesRead];
            Buffer.BlockCopy(buffer, 0, result, 0, bytesRead);
            return result;
        }

        /// <summary>
        /// 刷新输入和输出缓冲区。
        /// </summary>
        public bool DiscardBuffers()
        {
            if (!IsConnected) return false;
            return Win32Native.PurgeComm(ComPort.port_fd, 10u) && Win32Native.PurgeComm(ComPort.port_fd, 5u);
        }

        /// <summary>
        /// 关闭端口并刷新文件缓冲区。
        /// </summary>
        public void Close()
        {
            if (IsConnected)
            {
                Win32Native.FlushFileBuffers(ComPort.port_fd);
                ComPort.port_fd.Close();
                IsConnected = false;
            }
        }

        /// <summary>
        /// 释放资源。
        /// </summary>
        public void Dispose()
        {
            Close();
        }
    }
}
