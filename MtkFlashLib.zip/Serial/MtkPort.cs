using System;
using System.IO;
using System.Linq;
using System.Management;
using System.Threading;
using MtkFlashLib.Utils;

namespace MtkFlashLib.Serial
{
    /// <summary>
    /// MTK 端口管理类，负责检测 MediaTek 设备、打开串口连接、执行寄存器读写及握手同步等操作。
    /// </summary>
    public class MtkPort
    {
        private readonly MtkContext _context;
        private readonly SerialLib _serial;

        /// <summary>当前激活的端口名称（如 "COM3"）</summary>
        public string ActivePortName { get; set; }
        /// <summary>当前激活的端口编号（如 "3"）</summary>
        public string ActivePortNum { get; set; }

        /// <summary>
        /// 构造函数，注入上下文与串口库依赖。
        /// </summary>
        public MtkPort(MtkContext context, SerialLib serial)
        {
            _context = context;
            _serial = serial;
        }

        /// <summary>
        /// 通过 WMI 查询扫描 PnP 实体注册表，检测已连接的 MediaTek 设备。
        /// </summary>
        public bool DetectMediaTekPort()
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                    "root\\cimv2",
                    "SELECT * FROM Win32_PnPEntity WHERE Name LIKE '%MediaTek%'"))
                {
                    foreach (ManagementObject queryObj in searcher.Get())
                    {
                        string nameString = queryObj["Name"]?.ToString();
                        if (string.IsNullOrEmpty(nameString)) continue;

                        // 查找名称中的 COM 端口标识
                        int comIdx = nameString.IndexOf("(COM");
                        if (comIdx != -1)
                        {
                            ActivePortNum = nameString.Substring(comIdx + 4).TrimEnd(')');
                            ActivePortName = nameString;
                            _context?.Log($"发现 MediaTek 设备位于: {ActivePortName} (COM{ActivePortNum})", MtkLogLevel.Info);
                            return true;
                        }
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                _context?.Log("DetectMediaTekPort WMI 错误: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 打开已配置的串行链路连接。
        /// </summary>
        public bool Open(string portNum = null)
        {
            string target = portNum ?? ActivePortNum;
            if (string.IsNullOrEmpty(target))
            {
                _context?.Log("无法在空的 COM 端口索引上打开通道。", MtkLogLevel.Error);
                return false;
            }

            ActivePortNum = target;
            ActivePortName = $"COM{target}";
            return _serial.Open($"\\\\.\\COM{target}");
        }

        /// <summary>
        /// 执行 32 位寄存器写入命令。
        /// </summary>
        public void Write32(string addrHex, string wordsHex, bool verify = true)
        {
            Echo("d4", 1);
            Echo(addrHex, 4);

            // 去除空格并保证偶数长度
            string words = wordsHex.Replace(" ", "");
            if (words.Length % 2 != 0)
            {
                words = "0" + words;
            }

            string lenHex = (words.Length / 2).ToString("X");
            Echo(lenHex, 4);

            byte[] status = _serial.ReadUSB(2);
            VerifyResponse(AddOn.BytesToHexString(status), "0001");

            Echo(words, 4);
            if (verify)
            {
                status = _serial.ReadUSB(2);
                VerifyResponse(AddOn.BytesToHexString(status), "0001");
            }
        }

        /// <summary>
        /// 执行标准 MediaTek 四阶段握手（0xA0 -> 0x0A -> 0x50 -> 0x05），与 BROM 同步。
        /// </summary>
        public bool HandshakeMtk()
        {
            try
            {
                byte[] startCmd = new byte[] { 160, 10, 80, 5 }; // [0xA0, 0x0A, 0x50, 0x05]
                int retry = 0;
                int step = 0;

                while (step < startCmd.Length)
                {
                    _serial.WriteUSB(new byte[] { startCmd[step] });
                    byte[] response = _serial.ReadUSB(1);

                    // 校验响应是否为当前命令的按位取反值
                    if (response.Length > 0 && response[0] == (byte)(~startCmd[step] & 0xFF))
                    {
                        step++;
                        continue;
                    }

                    // 清空输入输出缓冲区后重试
                    _serial.DiscardInBuffer();
                    _serial.DiscardOutBuffer();

                    if (retry >= 15)
                    {
                        _context?.Log("MTK 握手超时 - BROM 对齐查询状态无响应。", MtkLogLevel.Error);
                        _serial.Close();
                        return false;
                    }
                    retry++;
                }

                _context?.Log("握手已成功与 MTK BROM 同步。", MtkLogLevel.Success);
                return true;
            }
            catch (Exception ex)
            {
                _context?.Log("HandshakeMtk 异常: " + ex.Message, MtkLogLevel.Error);
                return false;
            }
        }

        /// <summary>
        /// 通过已打开的 USB 管道发送数据。
        /// </summary>
        public void WritePort(byte[] data)
        {
            _serial.WriteUSB(data);
        }

        /// <summary>
        /// 执行同步命令查询回显检查。
        /// </summary>
        public void Echo(string inputHex, int expectedBytes)
        {
            // 去除空格并保证偶数长度
            string payload = inputHex.Replace(" ", "");
            if (payload.Length % 2 != 0)
            {
                payload = "0" + payload;
            }

            // 根据期望字节数调整负载长度（补零或截断）
            int currentBytes = payload.Length / 2;
            if (currentBytes < expectedBytes)
            {
                payload = payload.PadLeft(expectedBytes * 2, '0');
            }
            else if (currentBytes > expectedBytes)
            {
                payload = payload.Substring(0, expectedBytes * 2);
            }

            byte[] cmd = AddOn.HexStringToBytes(payload);
            _serial.WriteUSB(cmd);

            byte[] response = _serial.ReadUSB(expectedBytes);
            VerifyResponse(payload, AddOn.BytesToHexString(response));
        }

        /// <summary>
        /// 查询执行包，期望特定返回头部及校验结果。
        /// </summary>
        public bool Send00000(int responseBytes, string taskContext, string hexPayload, string delayMs = "0")
        {
            if (string.IsNullOrEmpty(hexPayload)) hexPayload = "00000000";
            if (string.IsNullOrEmpty(delayMs)) delayMs = "0";

            int.TryParse(delayMs, out int delay);
            _serial.WriteUSB(AddOn.HexStringToBytes("EFEEEEFE01000000" + hexPayload));

            if (delay > 0)
            {
                Thread.Sleep(delay);
            }

            byte[] statusBytes = _serial.ReadUSB(responseBytes);
            string status = AddOn.BytesToHexString(statusBytes);

            // 校验魔术头
            string magicHeader = "efeeeefe";
            if (!status.StartsWith(magicHeader))
            {
                _context?.Log($"命令头部不匹配，操作: {taskContext}。收到: {status}", MtkLogLevel.Error);
                return false;
            }

            // 最后一个字节为 0x00 表示成功完成
            if (status.Length == responseBytes * 2 && !status.EndsWith("00"))
            {
                string errorCode = status.Substring(status.Length - 8);
                _context?.Log($"操作 '{taskContext}' 抛出错误码: 0x{errorCode}", MtkLogLevel.Error);
                return false;
            }

            return true;
        }

        /// <summary>
        /// 验证负载匹配结果，发生错误时抛出日志消息。
        /// </summary>
        public bool VerifyResponse(string expectedHex, string actualHex)
        {
            if (expectedHex.ToLower() != actualHex.ToLower())
            {
                _context?.Log($"回显验证不匹配: 期望 '{expectedHex}' 但得到 '{actualHex}'", MtkLogLevel.Warning);
                return false;
            }
            return true;
        }

        /// <summary>
        /// 将自定义 MTK 设备错误状态转换为本地化日志级别。
        /// </summary>
        public void LogMtkError(byte[] errorBytes)
        {
            string hexCode = AddOn.BytesToHexString(errorBytes);
            _context?.Log($"MTK 核心接口报告错误寄存器状态: 0x{hexCode}", MtkLogLevel.Error);
        }
    }
}
