using System;

namespace MtkFlashLib
{
    /// <summary>
    /// MTK 刷机上下文类，包含刷机会话的配置参数、状态信息、日志回调及进度报告接口。
    /// </summary>
    public class MtkContext
    {
        /// <summary>
        /// Pluggable logger interface instance.
        /// </summary>
        public IMtkLogger Logger { get; set; }

        /// <summary>
        /// MTK ROM/RAM partition values.
        /// </summary>
        public int RpmbSize { get; set; }

        /// <summary>
        /// Target save folder path.
        /// </summary>
        public string FolderSave { get; set; } = "tmp";

        /// <summary>
        /// Currently loaded Download Agent address or state.
        /// </summary>
        public string LoadedDa { get; set; } = "0x0";

        /// <summary>
        /// Active flash / login service ID.
        /// </summary>
        public int ServiceId { get; set; }

        /// <summary>
        /// Determines if the device read action is read-only.
        /// </summary>
        public bool IsReadOnly { get; set; }

        /// <summary>
        /// Connected target SOC project name.
        /// </summary>
        public string ProjectName { get; set; } = "none";

        /// <summary>
        /// Connected target SOC platform name.
        /// </summary>
        public string PlatformName { get; set; } = "none";

        /// <summary>
        /// Authorized signature token payload from the auth validation server.
        /// </summary>
        public string DataAuth { get; set; } = "";

        /// <summary>
        /// Output validation config blob data.
        /// </summary>
        public string ConfigData { get; set; } = "";

        /// <summary>
        /// MediaTek USB Vendor ID.
        /// </summary>
        public string Vid { get; set; } = "0x0e8d"; // Default MTK VID

        /// <summary>
        /// MediaTek USB Product ID.
        /// </summary>
        public string Pid { get; set; } = "0x0003"; // Default MTK PID

        /// <summary>
        /// Locally parsed/dumped Preloader binary image file bytes.
        /// </summary>
        public byte[] PreloaderFile { get; set; } = Array.Empty<byte>();

        /// <summary>
        /// Enable automatic bypass authentication check flags.
        /// </summary>
        public bool BypassAuth { get; set; } = true;

        /// <summary>
        /// Enable option to crash BROM to gain bypass execution context.
        /// </summary>
        public bool CrashBrom { get; set; } = false;

        /// <summary>
        /// Automatic device reboot toggle command flag upon writing processes success.
        /// </summary>
        public bool AutoReboot { get; set; } = true;

        /// <summary>
        /// Enabled preloader backup dump during standard partition parsing functions.
        /// </summary>
        public bool DumpPreloader { get; set; } = true;

        /// <summary>
        /// Custom EMI file or configuration path context references.
        /// </summary>
        public string CustomEmiPath { get; set; } = "";

        /// <summary>
        /// Enable custom EMI loading options during device initializations.
        /// </summary>
        public bool UseCustomEmi { get; set; } = false;

        /// <summary>
        /// Custom auth signature configuration file path.
        /// </summary>
        public string CustomAuthPath { get; set; } = "";

        /// <summary>
        /// Automatically query signature authentications via associated credential keys.
        /// </summary>
        public bool AutoAuthSv5 { get; set; } = true;

        /// <summary>
        /// Custom local directory target containing scatter configs.
        /// </summary>
        public string ScatterDirectory { get; set; } = "";

        /// <summary>
        /// Generates a logging instruction.
        /// </summary>
        public void Log(string message, MtkLogLevel level = MtkLogLevel.Info)
        {
            Logger?.Log(message, level);
        }

        /// <summary>
        /// Generates a progress update.
        /// </summary>
        public void UpdateProgress(string task, long current, long total, string details = "")
        {
            Logger?.UpdateProgress(task, current, total, details);
        }
    }
}
